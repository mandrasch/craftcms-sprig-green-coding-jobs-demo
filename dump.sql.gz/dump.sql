-- MySQL dump 10.13  Distrib 8.0.33, for Linux (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_kdbosijumtnhzdhzlqcczhrqrtictvyzcxjn` (`primaryOwnerId`),
  CONSTRAINT `fk_kdbosijumtnhzdhzlqcczhrqrtictvyzcxjn` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xavyvyajahjezzkcjpvofwzekrolalobhrkz` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ocslnmsevahgjvwhgrkgoxhsyfenupshyrxq` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_nrhpbkrpbumyhunxwmybxxwdhzudzjvlshlm` (`dateRead`),
  KEY `fk_kvoxqevpsciofiifoafptczeetabogpnhzfd` (`pluginId`),
  CONSTRAINT `fk_escplipbisemqlfzkculzcuaeixshnjagryu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kvoxqevpsciofiifoafptczeetabogpnhzfd` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fzzxnyoufhsfocdiklhlpirmzzirfrfztwty` (`sessionId`,`volumeId`),
  KEY `idx_qmnejagktpsforcgbzeqzmjokozjbnhigifn` (`volumeId`),
  CONSTRAINT `fk_mpuioecxysmvnzqvciqwiffhbrfbyndunppw` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pqkaaduzwynglawlezcqjlzhmnxfapmqfmyp` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gazqtqamqfhvicxagecwwymebsptxzcjjxwk` (`filename`,`folderId`),
  KEY `idx_utqlvvgokbiljwwciohietircmbzwfxbpqtg` (`folderId`),
  KEY `idx_xjapihrtumuinkfqnqpatrynjtrynyvvdhft` (`volumeId`),
  KEY `fk_dsczfqwfiwcowpzaczeknhutplevrnyvzwkj` (`uploaderId`),
  CONSTRAINT `fk_dsczfqwfiwcowpzaczeknhutplevrnyvzwkj` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_gmijzdrnhnpkyyexlrwogohmykyepgapjglx` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qeupzmeybzjqngqpqroamfzeqvjjnufetnos` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ygckddqmivmayxgfeaqlrhqkbwdnholrfzzm` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (12,1,1,1,'rivage-Fa9b57hffnM-unsplash.jpg','image',NULL,5184,3456,1751860,NULL,NULL,NULL,'2024-05-11 17:32:15','2024-05-11 17:32:15','2024-05-11 17:32:15');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_zvccunyssygiifpccudrfmtazpwjuvlsgwsz` (`siteId`),
  CONSTRAINT `fk_aifgrqbakpnormriozdyhtjhbareavmjyuid` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zvccunyssygiifpccudrfmtazpwjuvlsgwsz` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
INSERT INTO `assets_sites` VALUES (12,1,NULL);
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_uoawmtvjuiqkkeiqesvuicqwlsbzvimnsrwi` (`userId`),
  CONSTRAINT `fk_uoawmtvjuiqkkeiqesvuicqwlsbzvimnsrwi` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_caches`
--

DROP TABLE IF EXISTS `blitz_caches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_caches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `siteId` int NOT NULL,
  `uri` varchar(255) NOT NULL,
  `paginate` int DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_imidmggthngrmttusatryxqfpystgjoizech` (`siteId`,`uri`),
  KEY `idx_pixlkdtighbeopxtayafqyxkhjfncondlupt` (`expiryDate`),
  CONSTRAINT `fk_zfdmwymddngubursgqrtvtdexepvzdqtgkpj` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_caches`
--

LOCK TABLES `blitz_caches` WRITE;
/*!40000 ALTER TABLE `blitz_caches` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_caches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_cachetags`
--

DROP TABLE IF EXISTS `blitz_cachetags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_cachetags` (
  `cacheId` int NOT NULL,
  `tag` varchar(255) NOT NULL,
  PRIMARY KEY (`cacheId`,`tag`),
  KEY `idx_ondqfbwzalmfskjryyxhwivcbpdqzarxnkmm` (`tag`),
  CONSTRAINT `fk_hkdlqbzpzxrzzvpewmyiyldextifgzvidxot` FOREIGN KEY (`cacheId`) REFERENCES `blitz_caches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_cachetags`
--

LOCK TABLES `blitz_cachetags` WRITE;
/*!40000 ALTER TABLE `blitz_cachetags` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_cachetags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_driverdata`
--

DROP TABLE IF EXISTS `blitz_driverdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_driverdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `driver` varchar(255) NOT NULL,
  `data` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_driverdata`
--

LOCK TABLES `blitz_driverdata` WRITE;
/*!40000 ALTER TABLE `blitz_driverdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_driverdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementcaches`
--

DROP TABLE IF EXISTS `blitz_elementcaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementcaches` (
  `cacheId` int NOT NULL,
  `elementId` int NOT NULL,
  PRIMARY KEY (`cacheId`,`elementId`),
  KEY `fk_nvqsaodcysehqkhqfdtyjpysosdueuvxkfdz` (`elementId`),
  CONSTRAINT `fk_nvqsaodcysehqkhqfdtyjpysosdueuvxkfdz` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qkhmdvdrpwtptksghzdllkcblpsclcyrbuin` FOREIGN KEY (`cacheId`) REFERENCES `blitz_caches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementcaches`
--

LOCK TABLES `blitz_elementcaches` WRITE;
/*!40000 ALTER TABLE `blitz_elementcaches` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_elementcaches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementexpirydates`
--

DROP TABLE IF EXISTS `blitz_elementexpirydates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementexpirydates` (
  `elementId` int NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`),
  UNIQUE KEY `idx_rtvxvrrpawezrsakyqkncxlwrnskfzcqgwfe` (`elementId`),
  KEY `idx_nshmoufwoyecsvvhfkfejbteuxvtrrpuxojz` (`expiryDate`),
  CONSTRAINT `fk_wpzxnpqrapgyfxsqkdvsqyukzqhyqtjtszdg` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementexpirydates`
--

LOCK TABLES `blitz_elementexpirydates` WRITE;
/*!40000 ALTER TABLE `blitz_elementexpirydates` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_elementexpirydates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementfieldcaches`
--

DROP TABLE IF EXISTS `blitz_elementfieldcaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementfieldcaches` (
  `cacheId` int NOT NULL,
  `elementId` int NOT NULL,
  `fieldId` int NOT NULL,
  PRIMARY KEY (`cacheId`,`elementId`,`fieldId`),
  KEY `fk_efzcntvdefeguvveeeonifsywmuqoqgxcyoe` (`elementId`),
  KEY `fk_kfdtcjbetnonxuvytebdhfordyoilzmlhiqu` (`fieldId`),
  CONSTRAINT `fk_efzcntvdefeguvveeeonifsywmuqoqgxcyoe` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_kfdtcjbetnonxuvytebdhfordyoilzmlhiqu` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_uaiweabbzvfcszkjnajudwaktdynpheqeaya` FOREIGN KEY (`cacheId`) REFERENCES `blitz_caches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementfieldcaches`
--

LOCK TABLES `blitz_elementfieldcaches` WRITE;
/*!40000 ALTER TABLE `blitz_elementfieldcaches` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_elementfieldcaches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementqueries`
--

DROP TABLE IF EXISTS `blitz_elementqueries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementqueries` (
  `id` int NOT NULL AUTO_INCREMENT,
  `index` bigint NOT NULL,
  `type` varchar(255) NOT NULL,
  `params` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rowcaphlljoofhaqtivpawaeqgwjhrsvznrp` (`index`),
  KEY `idx_nelypfyseraujeshfipqxejjumvswqgtodvk` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementqueries`
--

LOCK TABLES `blitz_elementqueries` WRITE;
/*!40000 ALTER TABLE `blitz_elementqueries` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_elementqueries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementqueryattributes`
--

DROP TABLE IF EXISTS `blitz_elementqueryattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementqueryattributes` (
  `queryId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  PRIMARY KEY (`queryId`,`attribute`),
  CONSTRAINT `fk_lhttdlzrztpdvnecleulmxignvjorlwcrpnj` FOREIGN KEY (`queryId`) REFERENCES `blitz_elementqueries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementqueryattributes`
--

LOCK TABLES `blitz_elementqueryattributes` WRITE;
/*!40000 ALTER TABLE `blitz_elementqueryattributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_elementqueryattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementquerycaches`
--

DROP TABLE IF EXISTS `blitz_elementquerycaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementquerycaches` (
  `cacheId` int NOT NULL,
  `queryId` int NOT NULL,
  PRIMARY KEY (`cacheId`,`queryId`),
  KEY `fk_tequflmfhocuimhygzpqesvzwmabhwzdxxvp` (`queryId`),
  CONSTRAINT `fk_tequflmfhocuimhygzpqesvzwmabhwzdxxvp` FOREIGN KEY (`queryId`) REFERENCES `blitz_elementqueries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_unckvqyvzjektyyqtqztwecgenmscpzieixc` FOREIGN KEY (`cacheId`) REFERENCES `blitz_caches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementquerycaches`
--

LOCK TABLES `blitz_elementquerycaches` WRITE;
/*!40000 ALTER TABLE `blitz_elementquerycaches` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_elementquerycaches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementqueryfields`
--

DROP TABLE IF EXISTS `blitz_elementqueryfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementqueryfields` (
  `queryId` int NOT NULL,
  `fieldId` int NOT NULL,
  PRIMARY KEY (`queryId`,`fieldId`),
  KEY `fk_dgygqwxbeipbnyssgkrvnaavofelgfcdpvcn` (`fieldId`),
  CONSTRAINT `fk_dgygqwxbeipbnyssgkrvnaavofelgfcdpvcn` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mdetozmzcunliftibgbdjmtgtdcdlyotcgkt` FOREIGN KEY (`queryId`) REFERENCES `blitz_elementqueries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementqueryfields`
--

LOCK TABLES `blitz_elementqueryfields` WRITE;
/*!40000 ALTER TABLE `blitz_elementqueryfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_elementqueryfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_elementquerysources`
--

DROP TABLE IF EXISTS `blitz_elementquerysources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_elementquerysources` (
  `queryId` int NOT NULL,
  `sourceId` int NOT NULL,
  PRIMARY KEY (`queryId`,`sourceId`),
  CONSTRAINT `fk_tcqyucpxfvtcieyefseprkxaewdrijnjftwn` FOREIGN KEY (`queryId`) REFERENCES `blitz_elementqueries` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_elementquerysources`
--

LOCK TABLES `blitz_elementquerysources` WRITE;
/*!40000 ALTER TABLE `blitz_elementquerysources` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_elementquerysources` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_hints`
--

DROP TABLE IF EXISTS `blitz_hints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_hints` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `template` varchar(255) NOT NULL,
  `line` int DEFAULT NULL,
  `stackTrace` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jdlhhppwsqmdrcfnuhratzdhoaetgdetsfuk` (`fieldId`,`template`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_hints`
--

LOCK TABLES `blitz_hints` WRITE;
/*!40000 ALTER TABLE `blitz_hints` DISABLE KEYS */;
INSERT INTO `blitz_hints` VALUES (1,6,'_sprig/jobSearch.twig',111,'_sprig/jobSearch.twig:111','2024-05-11 17:29:27','2024-07-03 19:45:39','10128a3d-ceba-4bda-ad3d-8025a9c3aec8');
/*!40000 ALTER TABLE `blitz_hints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_includes`
--

DROP TABLE IF EXISTS `blitz_includes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_includes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `index` bigint NOT NULL,
  `siteId` int NOT NULL,
  `template` varchar(255) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cfjbckvaceicoayxrjtviljtcrrmxeibhkxm` (`index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_includes`
--

LOCK TABLES `blitz_includes` WRITE;
/*!40000 ALTER TABLE `blitz_includes` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_includes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_ssiincludecaches`
--

DROP TABLE IF EXISTS `blitz_ssiincludecaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blitz_ssiincludecaches` (
  `cacheId` int NOT NULL,
  `includeId` int NOT NULL,
  PRIMARY KEY (`cacheId`,`includeId`),
  KEY `fk_qnsenpzhqpiwfcyljgivraozlxtppjvjjfxl` (`includeId`),
  CONSTRAINT `fk_osvkqvlqsbrgckngjskbairzkhzenvyzyjnj` FOREIGN KEY (`cacheId`) REFERENCES `blitz_caches` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_qnsenpzhqpiwfcyljgivraozlxtppjvjjfxl` FOREIGN KEY (`includeId`) REFERENCES `blitz_includes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_ssiincludecaches`
--

LOCK TABLES `blitz_ssiincludecaches` WRITE;
/*!40000 ALTER TABLE `blitz_ssiincludecaches` DISABLE KEYS */;
/*!40000 ALTER TABLE `blitz_ssiincludecaches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ewljkvmbpgxqfvptxlzubpjfmsvvrclfqgip` (`groupId`),
  KEY `fk_luaszmxpotpgokibmrkyphcviuujhufrxnch` (`parentId`),
  CONSTRAINT `fk_calqqjidmihvakzmcagbacvtdmaekdletiey` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_luaszmxpotpgokibmrkyphcviuujhufrxnch` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_pedcqnkgesczwemhccmpkklplgsyoxlmvwwt` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (2,1,NULL,NULL,'2024-05-11 12:49:59','2024-05-11 12:49:59'),(3,1,NULL,NULL,'2024-05-11 12:50:21','2024-05-11 12:50:21'),(10,1,NULL,NULL,'2024-05-11 17:30:21','2024-05-11 17:30:21'),(11,1,NULL,NULL,'2024-05-11 17:30:44','2024-05-11 17:30:44');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vufrgrmvzsnoilwinzzmcevxabrfcpdzgcfg` (`name`),
  KEY `idx_ojogpbejmrjyyasmxjrdqhboyovqhxxtgnfi` (`handle`),
  KEY `idx_fjksnbkspexgegqczabwvpnxodhwyxtikuvi` (`structureId`),
  KEY `idx_esnyhclpwmfpxapuctcjlqzbrwrwibbugajm` (`fieldLayoutId`),
  KEY `idx_ywdoqapuzzvymswsyfsxdlecvxhvpbbwaqnu` (`dateDeleted`),
  CONSTRAINT `fk_jcwocbgiiwvkzbafpxhnszqcceaaxslcfzux` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xvglvjtxscaarseghtcocsiynrbertnwwhdw` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
INSERT INTO `categorygroups` VALUES (1,1,1,'Job Benefit Categories','jobBenefitCategories','end','2024-05-11 11:57:11','2024-05-11 11:57:11',NULL,'0e530a56-1ab2-4445-9fb2-c10cb2de5d23');
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lthoshqcstoyilbuyowfdduvqwcbfltpddmr` (`groupId`,`siteId`),
  KEY `idx_naeaxbidkxhbyeieojejlxmtklxyqwacyize` (`siteId`),
  CONSTRAINT `fk_jvangvmujxhwkqcpksldixkpglivfuuqzjvh` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sgrfurxmmdjpjyuxgfndirbwgjvzblyakeal` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
INSERT INTO `categorygroups_sites` VALUES (1,1,1,1,'job-category/{slug}',NULL,'2024-05-11 11:57:11','2024-05-11 11:57:11','1ba4d9b5-a047-44e7-abfc-1fc3394e118c');
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_bkbwxssywoaomyrjigvpuyfgwcuphhqhtevz` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_chaluuxlaxfgwojouxojzsfthvxdqvfxlhyk` (`siteId`),
  KEY `fk_dzzhuyrgoflrapqgpmxlquouorgyqjruxdow` (`userId`),
  CONSTRAINT `fk_chaluuxlaxfgwojouxojzsfthvxdqvfxlhyk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_dzzhuyrgoflrapqgpmxlquouorgyqjruxdow` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_mnwmeinqyptqppatkybcgnczgbdpkmjgxouz` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (2,1,'slug','2024-05-11 12:50:07',0,1),(2,1,'title','2024-05-11 12:50:07',0,1),(2,1,'uri','2024-05-11 12:50:07',0,1),(3,1,'slug','2024-05-11 12:50:28',0,1),(3,1,'title','2024-05-11 12:50:28',0,1),(3,1,'uri','2024-05-11 12:50:28',0,1),(5,1,'postDate','2024-05-11 12:51:00',0,1),(5,1,'slug','2024-05-11 12:50:42',0,1),(5,1,'title','2024-05-11 12:50:42',0,1),(5,1,'uri','2024-05-11 12:50:42',0,1),(8,1,'postDate','2024-05-11 17:32:23',0,1),(8,1,'slug','2024-05-11 17:29:59',0,1),(8,1,'title','2024-05-11 17:29:59',0,1),(8,1,'uri','2024-05-11 17:29:59',0,1),(10,1,'slug','2024-05-11 17:30:32',0,1),(10,1,'title','2024-05-11 17:30:32',0,1),(10,1,'uri','2024-05-11 17:30:32',0,1),(11,1,'slug','2024-05-11 17:31:36',0,1),(11,1,'title','2024-05-11 17:31:36',0,1),(11,1,'uri','2024-05-11 17:31:36',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_fcxtrkliodcceghoixpvvkvpruulgpsolrtx` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_zpekiwleonfwocowwtqrmtfyfaghwazdsdit` (`siteId`),
  KEY `fk_tjdnoiitplbyhtlimavofvectmitwnxiemsy` (`fieldId`),
  KEY `fk_wswcxldtuenrpnxincyfyarnmmitpgivbfsu` (`userId`),
  CONSTRAINT `fk_iqibcqmlpawnbcspsulmiciwtweggmyolaqc` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tjdnoiitplbyhtlimavofvectmitwnxiemsy` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_wswcxldtuenrpnxincyfyarnmmitpgivbfsu` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_zpekiwleonfwocowwtqrmtfyfaghwazdsdit` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (2,1,1,'ef49b420-b96b-4795-a04f-9a919398c7f4','2024-05-11 12:50:18',0,1),(5,1,2,'5c4983fd-f41f-464d-8ba7-4e0a4a3e5844','2024-05-11 12:51:00',0,1),(5,1,3,'458088e4-9f47-4e90-a38e-ffc7ebdbf968','2024-05-11 17:32:31',0,1),(5,1,4,'11fc87ae-7df9-45df-8346-31f77920282b','2024-05-11 12:51:00',0,1),(5,1,5,'b1e586d3-bb59-4815-b952-a7b20f518554','2024-05-11 12:51:00',0,1),(5,1,6,'567a675d-edd6-4b68-8e07-ab7502571627','2024-05-11 17:32:31',0,1),(8,1,2,'5c4983fd-f41f-464d-8ba7-4e0a4a3e5844','2024-05-11 17:32:23',0,1),(8,1,3,'458088e4-9f47-4e90-a38e-ffc7ebdbf968','2024-05-11 17:32:23',0,1),(8,1,4,'11fc87ae-7df9-45df-8346-31f77920282b','2024-05-11 17:32:52',0,1),(8,1,5,'b1e586d3-bb59-4815-b952-a7b20f518554','2024-05-11 17:32:23',0,1),(8,1,6,'567a675d-edd6-4b68-8e07-ab7502571627','2024-05-11 17:32:23',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_fjimsaclmrarntyuviboiocyqcmjwczdytzw` (`userId`),
  CONSTRAINT `fk_fjimsaclmrarntyuviboiocyqcmjwczdytzw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_shnlzcyytkiqxikfgihgqivzadxpjviezdct` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_xhpzspulugmlgpqecqhmsenomubjkqqrfxii` (`creatorId`,`provisional`),
  KEY `idx_bskwlkrhpqnhvwuncgezblostpbmqcqlegay` (`saved`),
  KEY `fk_qdorsebksedxdortuczkxxsokekfzcipqfyr` (`canonicalId`),
  CONSTRAINT `fk_jwpfysbibwygjtwblowsixjvyyyyohxdbanz` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_qdorsebksedxdortuczkxxsokekfzcipqfyr` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
INSERT INTO `drafts` VALUES (3,NULL,1,0,'First draft',NULL,0,NULL,0);
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_xjwcgzjknzjzjjxcayhqmzodkbkvdaitadxm` (`elementId`,`timestamp`,`userId`),
  KEY `fk_iuxomyyfyghgddukwuztlgvssondmgzrhqge` (`userId`),
  KEY `fk_bjyxzkreblacziksznwzlfqbsbpdkuztfvcy` (`siteId`),
  KEY `fk_nmorzyxedrawloazefwrqnkrkkkqmcvbryqz` (`draftId`),
  CONSTRAINT `fk_bjyxzkreblacziksznwzlfqbsbpdkuztfvcy` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_iuxomyyfyghgddukwuztlgvssondmgzrhqge` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nmorzyxedrawloazefwrqnkrkkkqmcvbryqz` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xtuxfopjnntyqkqjnasfohyybagtxqmpnimt` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES (2,1,1,NULL,'save','2024-05-11 12:50:18'),(3,1,1,NULL,'save','2024-05-11 12:50:28'),(5,1,1,NULL,'edit','2024-05-11 17:32:29'),(5,1,1,NULL,'save','2024-05-11 17:32:31'),(8,1,1,NULL,'edit','2024-05-11 17:32:51'),(8,1,1,NULL,'save','2024-05-11 17:32:52'),(10,1,1,NULL,'save','2024-05-11 17:30:33'),(11,1,1,NULL,'save','2024-05-11 17:31:36');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_fctbnsiohehztfwbyhnzngiqelznsdalkgvj` (`dateDeleted`),
  KEY `idx_hhqckowluircuhrvfgogmtdayhthqrdqwmcl` (`fieldLayoutId`),
  KEY `idx_gffvycaokxbsplhcrrtzgjxnogclvfkgmulo` (`type`),
  KEY `idx_mjwwakakswaizanmydxnkwnkdpgerdxvgwqp` (`enabled`),
  KEY `idx_dozyuoabmhyvlclufmgktqtlezqsesoatecz` (`canonicalId`),
  KEY `idx_vblwtddgqdirexpwnczilzntoueubpxdkonb` (`archived`,`dateCreated`),
  KEY `idx_ysneapcdvrlazexpnzhjcttewlfcjazqhngy` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_fzgdkpgeomqyhuetaiwjrpimkzywbmzhywtl` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_jyapsqlzodkzfdjxzwwdrbdxoruspvvhfkcu` (`draftId`),
  KEY `fk_dhduyhvszuezznremmnvxgxrwbvafzysvvow` (`revisionId`),
  CONSTRAINT `fk_dhduyhvszuezznremmnvxgxrwbvafzysvvow` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jyapsqlzodkzfdjxzwwdrbdxoruspvvhfkcu` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ltjxxsihuogvtotjhfjssyfjsjiiamjhpsvz` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rignkhtmctegbwtlmfwbubvlltupykunmlel` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-05-11 11:57:11','2024-05-11 11:57:11',NULL,NULL,NULL,'e7112484-3372-49d6-8b1e-a83e945b8f3f'),(2,NULL,NULL,NULL,1,'craft\\elements\\Category',1,0,'2024-05-11 12:49:59','2024-05-11 12:50:18',NULL,NULL,NULL,'819c0653-7e59-4bfc-a038-b88176edfd3a'),(3,NULL,NULL,NULL,1,'craft\\elements\\Category',1,0,'2024-05-11 12:50:21','2024-05-11 12:50:28',NULL,NULL,NULL,'33b0ef1d-50de-47af-982e-d87d1dcea8a3'),(4,NULL,3,NULL,2,'craft\\elements\\Entry',1,0,'2024-05-11 12:50:33','2024-05-11 12:50:33',NULL,NULL,NULL,'3b0be760-58d3-4919-95f1-5fbc653ac31a'),(5,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-05-11 12:50:33','2024-05-11 17:32:31',NULL,NULL,NULL,'18d03128-d2d5-480f-b8d4-ce647bd57f5d'),(6,NULL,NULL,NULL,3,'craft\\elements\\Tag',1,0,'2024-05-11 12:50:55','2024-05-11 12:50:55',NULL,NULL,NULL,'7bee4495-c473-4fb3-8ff8-4dd4a268111c'),(7,5,NULL,1,2,'craft\\elements\\Entry',1,0,'2024-05-11 12:51:00','2024-05-11 12:51:00',NULL,NULL,NULL,'7c8a09f0-2683-48c0-a9f7-0a710345396d'),(8,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-05-11 17:29:43','2024-05-11 17:32:52',NULL,NULL,NULL,'e7ddb6d1-255f-45a1-807b-511e9578fc57'),(10,NULL,NULL,NULL,1,'craft\\elements\\Category',1,0,'2024-05-11 17:30:21','2024-05-11 17:30:33',NULL,NULL,NULL,'421a7a30-3f99-4c51-b55c-1dc5f240c862'),(11,NULL,NULL,NULL,1,'craft\\elements\\Category',1,0,'2024-05-11 17:30:44','2024-05-11 17:31:36',NULL,NULL,NULL,'d54f411a-5e3f-4957-895f-f3480aa929e0'),(12,NULL,NULL,NULL,4,'craft\\elements\\Asset',1,0,'2024-05-11 17:32:13','2024-05-11 17:32:13',NULL,NULL,NULL,'fda09087-2aa3-415a-9824-cba7635a015d'),(13,8,NULL,2,2,'craft\\elements\\Entry',1,0,'2024-05-11 17:32:23','2024-05-11 17:32:23',NULL,NULL,NULL,'be529425-9a28-4260-b15c-3341f970e999'),(14,5,NULL,3,2,'craft\\elements\\Entry',1,0,'2024-05-11 17:32:31','2024-05-11 17:32:31',NULL,NULL,NULL,'b5b36681-e013-4372-a8da-36e4be78f065'),(15,NULL,NULL,NULL,3,'craft\\elements\\Tag',1,0,'2024-05-11 17:32:51','2024-05-11 17:32:51',NULL,NULL,NULL,'1c22c716-fb9f-4c1d-8a34-1a729c58ffec'),(17,8,NULL,4,2,'craft\\elements\\Entry',1,0,'2024-05-11 17:32:52','2024-05-11 17:32:52',NULL,NULL,NULL,'845d0c22-b188-465c-89d5-7033c859d980'),(18,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:31','2024-07-03 19:21:31',NULL,NULL,NULL,'83070c39-0632-41a0-b3a0-55f840d1aa45'),(19,18,NULL,5,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:31','2024-07-03 19:21:31',NULL,NULL,NULL,'72cce845-36cc-4bb2-b579-3a16c3172379'),(20,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:33','2024-07-03 19:21:33',NULL,NULL,NULL,'28d330e5-354f-4494-b8ec-4ee12ebf88b8'),(21,20,NULL,6,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:33','2024-07-03 19:21:33',NULL,NULL,NULL,'805e7532-d018-40d8-9d96-d58154c3baaf'),(22,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:36','2024-07-03 19:21:36',NULL,NULL,NULL,'84c4f677-fe04-44e0-9f58-ee6dcfbb6fce'),(23,22,NULL,7,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:36','2024-07-03 19:21:36',NULL,NULL,NULL,'a113fec2-c68a-4e9b-b20a-3231773cf107'),(24,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:40','2024-07-03 19:21:40',NULL,NULL,NULL,'1c0a4e20-1f96-4de5-9fe0-c0c33fe0dfff'),(25,24,NULL,8,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:40','2024-07-03 19:21:40',NULL,NULL,NULL,'a464b60b-3c4e-4fdc-ab2a-24509c094e29'),(26,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:41','2024-07-03 19:21:41',NULL,NULL,NULL,'aafc7240-a5d4-49bb-ae56-ab2db65f63f6'),(27,26,NULL,9,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:41','2024-07-03 19:21:41',NULL,NULL,NULL,'428a274a-55ef-4d69-9358-5629060d3ce4'),(28,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:43','2024-07-03 19:21:43',NULL,NULL,NULL,'746929bc-c785-4cee-8b30-b97c9f3e8c82'),(29,28,NULL,10,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:43','2024-07-03 19:21:43',NULL,NULL,NULL,'2f649516-7472-44cc-8b79-1fe026f5f587'),(30,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:44','2024-07-03 19:21:44',NULL,NULL,NULL,'4f3a8447-f2d6-4cad-bcde-418ec46623f2'),(31,30,NULL,11,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:44','2024-07-03 19:21:44',NULL,NULL,NULL,'3b6a7674-83f5-441f-a3d3-ad43be2496c3'),(32,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:46','2024-07-03 19:21:46',NULL,NULL,NULL,'1e5d597a-3f76-41f9-842c-6529d7607e77'),(33,32,NULL,12,2,'craft\\elements\\Entry',1,0,'2024-07-03 19:21:46','2024-07-03 19:21:46',NULL,NULL,NULL,'c4bd140e-2d8e-4563-8867-254d843afc67');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_wlwtuzhsblgqfeaaarsajginbxzwstinitng` (`timestamp`),
  CONSTRAINT `fk_shttkzmroxqhdskcbubulhncgarpsgoasgde` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_blgmqvicqtqldxsankxkztulsoafietmhfiq` (`ownerId`),
  CONSTRAINT `fk_blgmqvicqtqldxsankxkztulsoafietmhfiq` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gaqopsojryixxmvikjuzgwzovkilvrnecsfc` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_boxjfbnxzewkahjvnqvuinmkortzmgaurfev` (`elementId`,`siteId`),
  KEY `idx_gkziktzwxexegnwjygvxwxgglhzfldunqxgb` (`siteId`),
  KEY `idx_yahprpjdtlrimrawlzdketwdfgffpnyoyfes` (`title`,`siteId`),
  KEY `idx_fzvgwugyxafvpwoepyodenoyafqhnagpbzft` (`slug`,`siteId`),
  KEY `idx_xnezjuncxodgtveshogjhvmjxhjedcadzuyc` (`enabled`),
  KEY `idx_sowcuiuisiemzfjqawvidasoaethrcykovri` (`uri`,`siteId`),
  CONSTRAINT `fk_tjsjaffektwawxqxuauwqejxxyowxdirvmtn` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ubyzkjrgfntmcyoatafybmthhddkgrvqxpcw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2024-05-11 11:57:11','2024-05-11 11:57:11','651ec1ca-c332-4f08-aac7-4e28bc687333'),(2,2,1,'4 day work week','4-day-work-week','job-category/4-day-work-week','{\"ef49b420-b96b-4795-a04f-9a919398c7f4\": \"4 day work week or reduced work time\"}',1,'2024-05-11 12:49:59','2024-05-11 12:50:17','1c5fb7ad-7b61-4dcf-8515-b1e7f78f0c35'),(3,3,1,'Public transport ticket','public-transport-ticket','job-category/public-transport-ticket',NULL,1,'2024-05-11 12:50:21','2024-05-11 12:50:28','2420cd0b-8b7b-48d1-a66b-2d9f5590df3a'),(4,4,1,NULL,'__temp_sumlcyxzbftbumycdyxslhiasrejdnkapyug','job/__temp_sumlcyxzbftbumycdyxslhiasrejdnkapyug',NULL,1,'2024-05-11 12:50:33','2024-05-11 12:50:33','ced44088-87f9-4169-914d-30120ff8a637'),(5,5,1,'Example PHP Job','example-php-job','job/example-php-job','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome PHP job\"}',1,'2024-05-11 12:50:33','2024-05-11 17:32:31','95aa04b0-06fd-46ee-976c-c6861a5bd791'),(6,6,1,'PHP','php',NULL,NULL,1,'2024-05-11 12:50:55','2024-05-11 12:50:55','d9f71a42-3188-43d3-b0fb-ce46f18e5b1e'),(7,7,1,'Example PHP Job','example-php-job','job/example-php-job','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome PHP job\"}',1,'2024-05-11 12:51:00','2024-05-11 12:51:00','afb383cd-9ac3-4f4b-bf33-778e804a75bd'),(8,8,1,'Example Svelte Job','example-svelte-job','job/example-svelte-job','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome Svelte job\"}',1,'2024-05-11 17:29:43','2024-05-11 17:32:52','4d2e7120-33a7-4904-b8dd-516d3f99a9c1'),(10,10,1,'Fruit basket','fruit-basket','job-category/fruit-basket',NULL,1,'2024-05-11 17:30:21','2024-05-11 17:30:32','cbd68577-7970-45fb-8c7f-d9d7e17e4dcd'),(11,11,1,'Night train journeys','night-train-journeys','job-category/night-train-journeys',NULL,1,'2024-05-11 17:30:44','2024-05-11 17:31:36','1342f461-9066-47f8-aa89-e9ac51de537e'),(12,12,1,'Rivage Fa9b57hffn M unsplash',NULL,NULL,NULL,1,'2024-05-11 17:32:13','2024-05-11 17:32:13','0861f713-671a-437e-8bf7-c77e24e046e1'),(13,13,1,'Example Svelte Job','example-svelte-job','job/example-svelte-job','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome Svelte job\"}',1,'2024-05-11 17:32:23','2024-05-11 17:32:23','13447e5d-11a5-4bf3-b64b-ea87e06d6305'),(14,14,1,'Example PHP Job','example-php-job','job/example-php-job','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome PHP job\"}',1,'2024-05-11 17:32:31','2024-05-11 17:32:31','50edaa5b-8173-4c40-8124-0e61aa351d4b'),(15,15,1,'Svelte','svelte',NULL,NULL,1,'2024-05-11 17:32:51','2024-05-11 17:32:51','ac325471-fa81-4d35-9a14-e2e072e54323'),(17,17,1,'Example Svelte Job','example-svelte-job','job/example-svelte-job','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome Svelte job\"}',1,'2024-05-11 17:32:52','2024-05-11 17:32:52','fef1ef32-4a40-4605-aeb1-4b0481aa04cc'),(18,18,1,'Example PHP Job','example-php-job-2','job/example-php-job-2','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome PHP job\"}',1,'2024-07-03 19:21:31','2024-07-03 19:21:31','bb2ce5f7-b5ce-40a1-86e5-83fff865a126'),(19,19,1,'Example PHP Job','example-php-job-2','job/example-php-job-2','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome PHP job\"}',1,'2024-07-03 19:21:31','2024-07-03 19:21:31','5542ea18-bf3a-43aa-abba-411ec58de266'),(20,20,1,'Example PHP Job','example-php-job-3','job/example-php-job-3','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome PHP job\"}',1,'2024-07-03 19:21:33','2024-07-03 19:21:33','24f63c35-b51a-4eb0-9475-b08def9a0fa9'),(21,21,1,'Example PHP Job','example-php-job-3','job/example-php-job-3','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome PHP job\"}',1,'2024-07-03 19:21:33','2024-07-03 19:21:33','3769c331-e57f-4c4a-997d-1548450fffb9'),(22,22,1,'Example PHP Job','example-php-job-4','job/example-php-job-4','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome PHP job\"}',1,'2024-07-03 19:21:36','2024-07-03 19:21:36','0906005a-2cc4-45da-a4b7-cb8abcf49c73'),(23,23,1,'Example PHP Job','example-php-job-4','job/example-php-job-4','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome PHP job\"}',1,'2024-07-03 19:21:36','2024-07-03 19:21:36','5e575d7c-347c-4cb9-a3f5-c134257bc150'),(24,24,1,'Example Svelte Job','example-svelte-job-2','job/example-svelte-job-2','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome Svelte job\"}',1,'2024-07-03 19:21:40','2024-07-03 19:21:40','723a90aa-105e-4a2e-aebf-45f17beb688d'),(25,25,1,'Example Svelte Job','example-svelte-job-2','job/example-svelte-job-2','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome Svelte job\"}',1,'2024-07-03 19:21:40','2024-07-03 19:21:40','a080ebc1-15d0-4a0e-9657-325df5dbf1ac'),(26,26,1,'Example Svelte Job','example-svelte-job-3','job/example-svelte-job-3','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome Svelte job\"}',1,'2024-07-03 19:21:41','2024-07-03 19:21:41','f3cd30e5-8e4d-44c3-b95d-1806cd2fa2e5'),(27,27,1,'Example Svelte Job','example-svelte-job-3','job/example-svelte-job-3','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome Svelte job\"}',1,'2024-07-03 19:21:41','2024-07-03 19:21:41','3fb00e82-e0e5-4339-ba90-efd88dd8302f'),(28,28,1,'Example Svelte Job','example-svelte-job-4','job/example-svelte-job-4','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome Svelte job\"}',1,'2024-07-03 19:21:43','2024-07-03 19:21:43','6ac525b6-86cf-4f2f-b4cc-ff997105cc45'),(29,29,1,'Example Svelte Job','example-svelte-job-4','job/example-svelte-job-4','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome Svelte job\"}',1,'2024-07-03 19:21:43','2024-07-03 19:21:43','3c230681-5c5e-4c07-a6fb-54314429f554'),(30,30,1,'Example Svelte Job','example-svelte-job-5','job/example-svelte-job-5','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome Svelte job\"}',1,'2024-07-03 19:21:44','2024-07-03 19:21:44','abefb2f0-1eac-4ff6-9274-020385fc30d3'),(31,31,1,'Example Svelte Job','example-svelte-job-5','job/example-svelte-job-5','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome Svelte job\"}',1,'2024-07-03 19:21:44','2024-07-03 19:21:44','1ba28e2b-00aa-4638-8af3-00dacc6ed7a8'),(32,32,1,'Example Svelte Job','example-svelte-job-6','job/example-svelte-job-6','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome Svelte job\"}',1,'2024-07-03 19:21:46','2024-07-03 19:21:46','f5290b86-4a23-4262-826e-fb93a1d0e31c'),(33,33,1,'Example Svelte Job','example-svelte-job-6','job/example-svelte-job-6','{\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\": \"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\", \"b1e586d3-bb59-4815-b952-a7b20f518554\": \"An awesome Svelte job\"}',1,'2024-07-03 19:21:46','2024-07-03 19:21:46','138b7959-5eed-4acc-8000-4e856d1d412d');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tgvhjxoosupmvclezhkqgdmpemfzodkfprqe` (`postDate`),
  KEY `idx_jgfcqfsacwilihfwtwxvkbwgjhsuucjgoaen` (`expiryDate`),
  KEY `idx_cokrkghstjahbtyvgfaowevcbjikzxlkcwga` (`sectionId`),
  KEY `idx_vidneptrqtdxqvtkusvxjqiqcytnrkxjmvuq` (`typeId`),
  KEY `idx_yxttdnleoingloujugcnslkjlrdpwiqaeoxb` (`primaryOwnerId`),
  KEY `idx_uuolaqylmpyzpzviqxwdbullyoqnwvyxqyri` (`fieldId`),
  KEY `fk_xzmithlclycqdwuklxozeazwxpgmfzlyvgjm` (`parentId`),
  CONSTRAINT `fk_bogyudbvalztvfmkmgkjpyxehjrktggqeqvk` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gibmcyggmgjpwyqhgrkscaxnqepfuughpxlx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hgrobvnjdxzrjhsvopewlvybovfmntmjwmqf` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mwcnjonxqttdpfoieichvrwenjkqwffqzcyp` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xzmithlclycqdwuklxozeazwxpgmfzlyvgjm` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zjdlheqacfrdwvapxloqbrrvyygdipyacinm` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (4,1,NULL,NULL,NULL,1,'2024-05-11 12:50:33',NULL,NULL,'2024-05-11 12:50:33','2024-05-11 12:50:33'),(5,1,NULL,NULL,NULL,1,'2024-05-11 12:51:00',NULL,NULL,'2024-05-11 12:50:33','2024-05-11 12:51:00'),(7,1,NULL,NULL,NULL,1,'2024-05-11 12:51:00',NULL,NULL,'2024-05-11 12:51:00','2024-05-11 12:51:00'),(8,1,NULL,NULL,NULL,1,'2024-05-11 17:32:00',NULL,NULL,'2024-05-11 17:29:43','2024-05-11 17:32:23'),(13,1,NULL,NULL,NULL,1,'2024-05-11 17:32:00',NULL,NULL,'2024-05-11 17:32:23','2024-05-11 17:32:23'),(14,1,NULL,NULL,NULL,1,'2024-05-11 12:51:00',NULL,NULL,'2024-05-11 17:32:31','2024-05-11 17:32:31'),(17,1,NULL,NULL,NULL,1,'2024-05-11 17:32:00',NULL,NULL,'2024-05-11 17:32:52','2024-05-11 17:32:52'),(18,1,NULL,NULL,NULL,1,'2024-05-11 12:51:00',NULL,NULL,'2024-07-03 19:21:31','2024-07-03 19:21:31'),(19,1,NULL,NULL,NULL,1,'2024-05-11 12:51:00',NULL,NULL,'2024-07-03 19:21:31','2024-07-03 19:21:31'),(20,1,NULL,NULL,NULL,1,'2024-05-11 12:51:00',NULL,NULL,'2024-07-03 19:21:33','2024-07-03 19:21:33'),(21,1,NULL,NULL,NULL,1,'2024-05-11 12:51:00',NULL,NULL,'2024-07-03 19:21:33','2024-07-03 19:21:33'),(22,1,NULL,NULL,NULL,1,'2024-05-11 12:51:00',NULL,NULL,'2024-07-03 19:21:36','2024-07-03 19:21:36'),(23,1,NULL,NULL,NULL,1,'2024-05-11 12:51:00',NULL,NULL,'2024-07-03 19:21:36','2024-07-03 19:21:36'),(24,1,NULL,NULL,NULL,1,'2024-05-11 17:32:00',NULL,NULL,'2024-07-03 19:21:40','2024-07-03 19:21:40'),(25,1,NULL,NULL,NULL,1,'2024-05-11 17:32:00',NULL,NULL,'2024-07-03 19:21:40','2024-07-03 19:21:40'),(26,1,NULL,NULL,NULL,1,'2024-05-11 17:32:00',NULL,NULL,'2024-07-03 19:21:41','2024-07-03 19:21:41'),(27,1,NULL,NULL,NULL,1,'2024-05-11 17:32:00',NULL,NULL,'2024-07-03 19:21:41','2024-07-03 19:21:41'),(28,1,NULL,NULL,NULL,1,'2024-05-11 17:32:00',NULL,NULL,'2024-07-03 19:21:43','2024-07-03 19:21:43'),(29,1,NULL,NULL,NULL,1,'2024-05-11 17:32:00',NULL,NULL,'2024-07-03 19:21:43','2024-07-03 19:21:43'),(30,1,NULL,NULL,NULL,1,'2024-05-11 17:32:00',NULL,NULL,'2024-07-03 19:21:44','2024-07-03 19:21:44'),(31,1,NULL,NULL,NULL,1,'2024-05-11 17:32:00',NULL,NULL,'2024-07-03 19:21:44','2024-07-03 19:21:44'),(32,1,NULL,NULL,NULL,1,'2024-05-11 17:32:00',NULL,NULL,'2024-07-03 19:21:46','2024-07-03 19:21:46'),(33,1,NULL,NULL,NULL,1,'2024-05-11 17:32:00',NULL,NULL,'2024-07-03 19:21:46','2024-07-03 19:21:46');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_hlbfilbmfcsilplajbmejxbaptquvxxziozc` (`authorId`),
  KEY `idx_eyvmtnlgdmadndzxgyjxocmskknrnihxbnqb` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_nduewlqgopzxqarsksboqmnrzdrajcijfvll` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wlojabhfqakslilhkqyawdtwvpoaxbrjpzkc` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
INSERT INTO `entries_authors` VALUES (4,1,1),(5,1,1),(7,1,1),(8,1,1),(13,1,1),(14,1,1),(17,1,1),(18,1,1),(19,1,1),(20,1,1),(21,1,1),(22,1,1),(23,1,1),(24,1,1),(25,1,1),(26,1,1),(27,1,1),(28,1,1),(29,1,1),(30,1,1),(31,1,1),(32,1,1),(33,1,1);
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wltcicfunkgodkaffitarmlgfqcsgttyeahn` (`fieldLayoutId`),
  KEY `idx_ncylaoymydnjiakqdxdiayminmocouptsxiv` (`dateDeleted`),
  CONSTRAINT `fk_aszsoavrvrmlqcawtihggivefirbqsjrpzyw` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,2,'Job','job','',NULL,1,'site',NULL,'',1,'site',NULL,1,'2024-05-11 11:57:11','2024-05-11 11:57:11',NULL,'671d7f33-b1cc-47a2-b318-351f6abed131');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nngxnctwgqpxwuzejaoecjjkvdezwtchqoim` (`dateDeleted`),
  KEY `idx_izsnoyzifwzuhdsgyqaivkhlailklliymfry` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Category','{\"tabs\": [{\"uid\": \"08b2f1d0-b0f9-40e1-be2a-9837eeb82a82\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"30c2901d-ba9c-4108-9be3-ac6dad180763\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\TitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"ef49b420-b96b-4795-a04f-9a919398c7f4\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Description\", \"width\": 100, \"handle\": \"description\", \"warning\": null, \"fieldUid\": \"65f42813-b1a9-4f17-bc3a-2d329422c5e4\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-05-11 11:57:11','2024-05-11 11:57:11',NULL,'9fc06d5b-a84b-4a52-aaff-72e969000558'),(2,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"7fe80068-e4ec-4c89-b177-a20404e9c247\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"54ceaa7a-f66f-4e3e-8da0-7f8487ac4cc2\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"b1e586d3-bb59-4815-b952-a7b20f518554\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Subline\", \"width\": 100, \"handle\": \"subline\", \"warning\": null, \"fieldUid\": \"a891b39d-03a3-45e3-b276-17186acb4746\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": \"Description\", \"width\": 100, \"handle\": \"description\", \"warning\": null, \"fieldUid\": \"fa292818-e2be-4621-a3fe-fa84e94dffd3\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"458088e4-9f47-4e90-a38e-ffc7ebdbf968\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"c8176449-1246-4efc-9b42-8e70f5b84306\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"11fc87ae-7df9-45df-8346-31f77920282b\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}, {\"tip\": null, \"uid\": \"567a675d-edd6-4b68-8e07-ab7502571627\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"9b0e5a91-7470-4931-8137-bf361cd4b2e2\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-05-11 11:57:11','2024-05-11 11:57:11',NULL,'b2c677aa-270a-4525-ac75-ab812873a9ef'),(3,'craft\\elements\\Tag','{\"tabs\": [{\"uid\": \"37881f0a-f631-4347-9f74-535d972c9c68\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"6d85b18f-e87f-48bb-a61a-e8f66634cb21\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\TitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-05-11 11:57:11','2024-05-11 11:57:11',NULL,'a0b274ef-3b6f-403a-b892-7bc9e80e6f2f'),(4,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"a78b82fb-ce8c-4522-9ce2-03ae723cc8b3\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"db8d499d-9f1b-42d2-a23c-974f2e0b91d5\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"id\": null, \"tip\": null, \"uid\": \"fdef8421-7e67-4d26-b654-73cdc36d26fd\", \"cols\": null, \"name\": null, \"rows\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"required\": false, \"attribute\": \"alt\", \"requirable\": true, \"orientation\": null, \"placeholder\": null, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-05-11 12:51:54','2024-05-11 12:51:54',NULL,'0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mpehavlzabpdtvjdpxmqcteoqpbqzrfglppi` (`handle`,`context`),
  KEY `idx_ymcofpbfcclagtxbylxzrppoawspjzevytgp` (`context`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,'Simple Multi-Line Text Field','simpleMultiLineTextField','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-05-11 11:57:10','2024-05-11 11:57:10','65f42813-b1a9-4f17-bc3a-2d329422c5e4'),(2,'Simple WYSIWYG Content','simpleWysiwygContent','global',NULL,NULL,0,'none',NULL,'craft\\ckeditor\\Field','{\"availableTransforms\":\"\",\"availableVolumes\":\"\",\"ckeConfig\":\"ff3cbecf-0f4e-4aff-a4f8-93bd8ac46501\",\"createButtonLabel\":null,\"defaultTransform\":null,\"enableSourceEditingForNonAdmins\":false,\"purifierConfig\":null,\"purifyHtml\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"showWordCount\":false,\"wordLimit\":null}','2024-05-11 11:57:11','2024-05-11 11:57:11','fa292818-e2be-4621-a3fe-fa84e94dffd3'),(3,'Job Benefit Categories','jobBenefitCategories','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Categories','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":false,\"source\":\"group:0e530a56-1ab2-4445-9fb2-c10cb2de5d23\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-05-11 11:57:11','2024-05-11 11:57:11','c8176449-1246-4efc-9b42-8e70f5b84306'),(4,'Job Programming Languages','jobProgrammingLanguages','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Tags','{\"allowSelfRelations\":false,\"branchLimit\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":false,\"source\":\"taggroup:37e6610b-1e23-42b3-8c84-853c2796c120\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":null}','2024-05-11 11:57:11','2024-05-11 11:57:11','f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b'),(5,'Simple One-Line Text Field','simpleOneLineTextField','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-05-11 11:57:11','2024-05-11 11:57:11','a891b39d-03a3-45e3-b276-17186acb4746'),(6,'Image','image','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":null,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a\",\"restrictedLocationSubpath\":null,\"selectionLabel\":null,\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-05-11 11:57:11','2024-05-11 17:29:25','9b0e5a91-7470-4931-8137-bf361cd4b2e2');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yfxgpbnznlhrekfayfegnekidnlueyyiydje` (`name`),
  KEY `idx_qdvxdmviwxvkxigvlclvnbzhiskylknwbvpj` (`handle`),
  KEY `idx_kvjcsaalnkshnoxdqhuxwvuixhcanjbpxqai` (`fieldLayoutId`),
  KEY `idx_rbxiqhprxgxsvwfwucgmimulllhweltmuuff` (`sortOrder`),
  CONSTRAINT `fk_fykjcjcgjgkuvuyeqdmmhdfvhjwxuhphswoy` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_sbsnmtibztxnqytxertdupcqxzehbabcfwiv` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xpqqwmuxabghrfeatxkiumpjobadrywaeqso` (`accessToken`),
  UNIQUE KEY `idx_aoyhdastklgcaazwzqahbyrsldhzaxubydpn` (`name`),
  KEY `fk_magzawnsvdrdzoxyhueyokghnmchcxwsming` (`schemaId`),
  CONSTRAINT `fk_magzawnsvdrdzoxyhueyokghnmchcxwsming` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_czpjjzaxowayzqjjluiheswikrobaozpgrht` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qzosiypjwrykaifbcszxhwxeecewnmhsarqu` (`name`),
  KEY `idx_rnkotxzxguubyyptoiaxatohecaocbncvhdt` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'5.1.2','5.0.0.20',0,'rcgqoxkqdnxn','3@dcqvmfousc','2024-05-11 11:57:10','2024-05-11 17:29:25','728b7f69-5550-47de-a144-6a6313166b35');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pqjqnrjwcqdhdquhzemoztsiwisznflwitif` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'plugin:blitz','Install','2024-05-11 11:57:10','2024-05-11 11:57:10','2024-05-11 11:57:10','44f08590-bca5-4868-9937-42e306d45c2e'),(2,'plugin:blitz','m240226_120000_drop_route_variable_hints_and_column','2024-05-11 11:57:10','2024-05-11 11:57:10','2024-05-11 11:57:10','c6a8c1c9-a0dd-4b57-ba74-8d882792b609'),(3,'plugin:blitz','m240310_120000_add_stack_trace','2024-05-11 11:57:10','2024-05-11 11:57:10','2024-05-11 11:57:10','eb22f3f5-88f8-4fc1-9e33-f049cd0feaff'),(4,'plugin:ckeditor','Install','2024-05-11 11:57:10','2024-05-11 11:57:10','2024-05-11 11:57:10','e1507d3c-e9b3-4975-91d3-f8c1981f2153'),(5,'plugin:ckeditor','m230408_163704_v3_upgrade','2024-05-11 11:57:10','2024-05-11 11:57:10','2024-05-11 11:57:10','accc9807-ef21-4094-a4a1-47164fde7318'),(6,'plugin:sprig','Install','2024-05-11 11:57:10','2024-05-11 11:57:10','2024-05-11 11:57:10','3f1f92f1-255b-4b2e-ae88-8acdc867c70d'),(7,'craft','Install','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','3aa97f67-d503-43d5-a093-703f3d3da8bc'),(8,'craft','m221101_115859_create_entries_authors_table','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','c0164e42-3f8f-4905-970c-aea81368a08a'),(9,'craft','m221107_112121_add_max_authors_to_sections','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','f941fb7f-3b9c-4b3d-bcac-48a35f7b6f7c'),(10,'craft','m221205_082005_translatable_asset_alt_text','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','4f050d67-8c01-4410-b24d-cf3f12a3c306'),(11,'craft','m230314_110309_add_authenticator_table','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','f008019a-4853-485e-9a03-8b4035825bc2'),(12,'craft','m230314_111234_add_webauthn_table','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','33e48bef-2022-45b3-9a32-9647063cf787'),(13,'craft','m230503_120303_add_recoverycodes_table','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','7abf4df7-7eab-4925-9926-8c9819df8f11'),(14,'craft','m230511_000000_field_layout_configs','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','46f1930f-b333-4631-8d77-e0f197f04f20'),(15,'craft','m230511_215903_content_refactor','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','0b0964f5-9389-43a3-aa49-6f98ee606e50'),(16,'craft','m230524_000000_add_entry_type_show_slug_field','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','4ad1c272-30a9-44ac-af13-74317c12b3ac'),(17,'craft','m230524_000001_entry_type_icons','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','9705d7a3-aa51-406e-9057-07b93d2c0fed'),(18,'craft','m230524_000002_entry_type_colors','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','3bed39d4-61ca-419b-9755-b05fe42bebb1'),(19,'craft','m230524_220029_global_entry_types','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','dc419d07-fbce-405c-80fa-0973e5eb6766'),(20,'craft','m230531_123004_add_entry_type_show_status_field','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','03d73747-1e47-4519-b9ef-d55b1e34fe77'),(21,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','58595aa9-7de7-40b2-895b-c0180a74b1f0'),(22,'craft','m230616_173810_kill_field_groups','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','42416eea-dbed-42e2-ad93-30fde61206ac'),(23,'craft','m230616_183820_remove_field_name_limit','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','d8488a14-b6bf-4efd-8bae-12f26f778d92'),(24,'craft','m230617_070415_entrify_matrix_blocks','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','5eed2de5-ffbf-40b1-8d99-5b345838c8ba'),(25,'craft','m230710_162700_element_activity','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','16caab05-5176-4334-96c7-1741428086e7'),(26,'craft','m230820_162023_fix_cache_id_type','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','4a0abcd7-536b-4f12-9aea-5c6a97a48dac'),(27,'craft','m230826_094050_fix_session_id_type','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','c6e80780-dbc0-434b-aeee-7648db8ca94f'),(28,'craft','m230904_190356_address_fields','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','e3b170de-df84-48a2-8505-a20330b6ddd7'),(29,'craft','m230928_144045_add_subpath_to_volumes','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','5b30e415-eb84-4584-ae4c-c88d2be49eb1'),(30,'craft','m231013_185640_changedfields_amend_primary_key','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','a0a1bbd2-1530-4feb-9cef-3028c651c681'),(31,'craft','m231213_030600_element_bulk_ops','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','c3b7ddc5-d4bd-4116-b3da-88ac64bf5730'),(32,'craft','m240129_150719_sites_language_amend_length','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','08ea5bab-3002-4e68-8ae2-c80ac30fab68'),(33,'craft','m240206_035135_convert_json_columns','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','abd485a3-0011-4010-909a-baf0f769e4b6'),(34,'craft','m240207_182452_address_line_3','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','9f741892-9c58-49e3-9c81-b285c883aee2'),(35,'craft','m240302_212719_solo_preview_targets','2024-05-11 11:57:11','2024-05-11 11:57:11','2024-05-11 11:57:11','75672dbe-0db1-4a61-a3ce-b69c2b1ec34e');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ddbdksmgtncxafpvhltyofszmjfbnxsbovcn` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'blitz','5.3.0','5.0.0.4','2024-05-11 11:57:10','2024-05-11 11:57:10','2024-05-11 12:34:03','f9181a73-632c-4aa5-88d5-7ad299c06713'),(2,'ckeditor','4.0.4','3.0.0.0','2024-05-11 11:57:10','2024-05-11 11:57:10','2024-05-11 11:57:10','fe083497-04a5-47cf-92fb-34276f0b7076'),(3,'imager-x','5.0.0','4.0.0','2024-05-11 11:57:10','2024-05-11 11:57:10','2024-05-11 11:57:10','e103c395-6dba-44c3-9946-0fcc5ef917ff'),(4,'sprig','3.0.1','1.0.1','2024-05-11 11:57:10','2024-05-11 11:57:10','2024-05-11 11:57:10','20f40bfb-8be4-474c-b13a-cb7bada46742'),(5,'empty-coalesce','5.0.0','1.0.0','2024-05-11 17:29:25','2024-05-11 17:29:25','2024-05-11 17:29:25','b9aa3285-5dd9-4b94-8d40-d94f382d935b'),(6,'imager-x-power-pack','1.0.0','1.0.0','2024-05-11 17:29:25','2024-05-11 17:29:25','2024-05-11 17:29:25','cbe0355c-47d1-41cb-b394-394ff3f3da8a');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.defaultPlacement','\"end\"'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elementCondition','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.autocapitalize','true'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.autocomplete','false'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.autocorrect','true'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.class','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.disabled','false'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.elementCondition','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.id','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.includeInCards','false'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.inputType','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.instructions','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.label','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.max','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.min','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.name','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.orientation','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.placeholder','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.providesThumbs','false'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.readonly','false'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.requirable','false'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.size','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.step','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.tip','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.title','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\TitleField\"'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.uid','\"30c2901d-ba9c-4108-9be3-ac6dad180763\"'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.userCondition','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.warning','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.0.width','100'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.1.elementCondition','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.1.fieldUid','\"65f42813-b1a9-4f17-bc3a-2d329422c5e4\"'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.1.handle','\"description\"'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.1.includeInCards','false'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.1.instructions','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.1.label','\"Description\"'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.1.providesThumbs','false'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.1.required','false'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.1.tip','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.1.uid','\"ef49b420-b96b-4795-a04f-9a919398c7f4\"'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.1.userCondition','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.1.warning','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.elements.1.width','100'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.name','\"Content\"'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.uid','\"08b2f1d0-b0f9-40e1-be2a-9837eeb82a82\"'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.fieldLayouts.9fc06d5b-a84b-4a52-aaff-72e969000558.tabs.0.userCondition','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.handle','\"jobBenefitCategories\"'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.name','\"Job Benefit Categories\"'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.siteSettings.b342a358-6ba6-41a2-b520-3bb922b51bde.hasUrls','true'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.siteSettings.b342a358-6ba6-41a2-b520-3bb922b51bde.template','null'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.siteSettings.b342a358-6ba6-41a2-b520-3bb922b51bde.uriFormat','\"job-category/{slug}\"'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.structure.maxLevels','1'),('categoryGroups.0e530a56-1ab2-4445-9fb2-c10cb2de5d23.structure.uid','\"a637430c-3835-4224-a061-6bac0abed042\"'),('ckeditor.configs.ff3cbecf-0f4e-4aff-a4f8-93bd8ac46501.headingLevels.0','1'),('ckeditor.configs.ff3cbecf-0f4e-4aff-a4f8-93bd8ac46501.headingLevels.1','2'),('ckeditor.configs.ff3cbecf-0f4e-4aff-a4f8-93bd8ac46501.headingLevels.2','3'),('ckeditor.configs.ff3cbecf-0f4e-4aff-a4f8-93bd8ac46501.headingLevels.3','4'),('ckeditor.configs.ff3cbecf-0f4e-4aff-a4f8-93bd8ac46501.headingLevels.4','5'),('ckeditor.configs.ff3cbecf-0f4e-4aff-a4f8-93bd8ac46501.headingLevels.5','6'),('ckeditor.configs.ff3cbecf-0f4e-4aff-a4f8-93bd8ac46501.name','\"Simple\"'),('ckeditor.configs.ff3cbecf-0f4e-4aff-a4f8-93bd8ac46501.toolbar.0','\"heading\"'),('ckeditor.configs.ff3cbecf-0f4e-4aff-a4f8-93bd8ac46501.toolbar.1','\"|\"'),('ckeditor.configs.ff3cbecf-0f4e-4aff-a4f8-93bd8ac46501.toolbar.2','\"bold\"'),('ckeditor.configs.ff3cbecf-0f4e-4aff-a4f8-93bd8ac46501.toolbar.3','\"italic\"'),('ckeditor.configs.ff3cbecf-0f4e-4aff-a4f8-93bd8ac46501.toolbar.4','\"link\"'),('dateModified','1715434631'),('email.fromEmail','\"admin@example.com\"'),('email.fromName','\"Green Coding Jobs\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.color','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elementCondition','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.autocapitalize','true'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.autocomplete','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.autocorrect','true'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.class','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.disabled','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.elementCondition','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.id','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.includeInCards','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.inputType','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.instructions','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.label','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.max','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.min','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.name','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.orientation','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.placeholder','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.providesThumbs','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.readonly','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.requirable','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.size','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.step','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.tip','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.title','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.uid','\"54ceaa7a-f66f-4e3e-8da0-7f8487ac4cc2\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.userCondition','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.warning','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.0.width','100'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.1.elementCondition','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.1.fieldUid','\"a891b39d-03a3-45e3-b276-17186acb4746\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.1.handle','\"subline\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.1.includeInCards','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.1.instructions','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.1.label','\"Subline\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.1.providesThumbs','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.1.required','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.1.tip','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.1.uid','\"b1e586d3-bb59-4815-b952-a7b20f518554\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.1.userCondition','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.1.warning','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.1.width','100'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.2.elementCondition','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.2.fieldUid','\"fa292818-e2be-4621-a3fe-fa84e94dffd3\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.2.handle','\"description\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.2.includeInCards','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.2.instructions','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.2.label','\"Description\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.2.providesThumbs','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.2.required','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.2.tip','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.2.uid','\"5c4983fd-f41f-464d-8ba7-4e0a4a3e5844\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.2.userCondition','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.2.warning','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.2.width','100'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.3.elementCondition','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.3.fieldUid','\"c8176449-1246-4efc-9b42-8e70f5b84306\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.3.handle','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.3.includeInCards','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.3.instructions','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.3.label','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.3.providesThumbs','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.3.required','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.3.tip','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.3.uid','\"458088e4-9f47-4e90-a38e-ffc7ebdbf968\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.3.userCondition','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.3.warning','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.3.width','100'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.4.elementCondition','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.4.fieldUid','\"f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.4.handle','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.4.includeInCards','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.4.instructions','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.4.label','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.4.providesThumbs','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.4.required','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.4.tip','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.4.uid','\"11fc87ae-7df9-45df-8346-31f77920282b\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.4.userCondition','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.4.warning','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.4.width','100'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.5.elementCondition','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.5.fieldUid','\"9b0e5a91-7470-4931-8137-bf361cd4b2e2\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.5.handle','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.5.includeInCards','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.5.instructions','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.5.label','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.5.providesThumbs','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.5.required','false'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.5.tip','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.5.uid','\"567a675d-edd6-4b68-8e07-ab7502571627\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.5.userCondition','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.5.warning','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.elements.5.width','100'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.name','\"Content\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.uid','\"7fe80068-e4ec-4c89-b177-a20404e9c247\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.fieldLayouts.b2c677aa-270a-4525-ac75-ab812873a9ef.tabs.0.userCondition','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.handle','\"job\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.hasTitleField','true'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.icon','\"\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.name','\"Job\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.showSlugField','true'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.showStatusField','true'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.slugTranslationKeyFormat','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.slugTranslationMethod','\"site\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.titleFormat','\"\"'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.titleTranslationKeyFormat','null'),('entryTypes.671d7f33-b1cc-47a2-b318-351f6abed131.titleTranslationMethod','\"site\"'),('fields.65f42813-b1a9-4f17-bc3a-2d329422c5e4.columnSuffix','null'),('fields.65f42813-b1a9-4f17-bc3a-2d329422c5e4.handle','\"simpleMultiLineTextField\"'),('fields.65f42813-b1a9-4f17-bc3a-2d329422c5e4.instructions','null'),('fields.65f42813-b1a9-4f17-bc3a-2d329422c5e4.name','\"Simple Multi-Line Text Field\"'),('fields.65f42813-b1a9-4f17-bc3a-2d329422c5e4.searchable','false'),('fields.65f42813-b1a9-4f17-bc3a-2d329422c5e4.settings.byteLimit','null'),('fields.65f42813-b1a9-4f17-bc3a-2d329422c5e4.settings.charLimit','null'),('fields.65f42813-b1a9-4f17-bc3a-2d329422c5e4.settings.code','false'),('fields.65f42813-b1a9-4f17-bc3a-2d329422c5e4.settings.initialRows','4'),('fields.65f42813-b1a9-4f17-bc3a-2d329422c5e4.settings.multiline','true'),('fields.65f42813-b1a9-4f17-bc3a-2d329422c5e4.settings.placeholder','null'),('fields.65f42813-b1a9-4f17-bc3a-2d329422c5e4.settings.uiMode','\"normal\"'),('fields.65f42813-b1a9-4f17-bc3a-2d329422c5e4.translationKeyFormat','null'),('fields.65f42813-b1a9-4f17-bc3a-2d329422c5e4.translationMethod','\"none\"'),('fields.65f42813-b1a9-4f17-bc3a-2d329422c5e4.type','\"craft\\\\fields\\\\PlainText\"'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.columnSuffix','null'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.handle','\"image\"'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.instructions','null'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.name','\"Image\"'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.searchable','false'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.allowedKinds','null'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.allowSelfRelations','false'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.allowSubfolders','false'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.allowUploads','true'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.branchLimit','null'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.defaultUploadLocationSource','\"volume:7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a\"'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.defaultUploadLocationSubpath','null'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.localizeRelations','false'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.maintainHierarchy','false'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.maxRelations','1'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.minRelations','null'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.previewMode','\"full\"'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.restrictedDefaultUploadSubpath','null'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.restrictedLocationSource','\"volume:7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a\"'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.restrictedLocationSubpath','null'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.restrictFiles','false'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.restrictLocation','false'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.selectionLabel','null'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.showCardsInGrid','false'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.showSiteMenu','true'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.showUnpermittedFiles','false'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.showUnpermittedVolumes','false'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.sources','\"*\"'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.targetSiteId','null'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.validateRelatedElements','false'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.settings.viewMode','\"list\"'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.translationKeyFormat','null'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.translationMethod','\"site\"'),('fields.9b0e5a91-7470-4931-8137-bf361cd4b2e2.type','\"craft\\\\fields\\\\Assets\"'),('fields.a891b39d-03a3-45e3-b276-17186acb4746.columnSuffix','null'),('fields.a891b39d-03a3-45e3-b276-17186acb4746.handle','\"simpleOneLineTextField\"'),('fields.a891b39d-03a3-45e3-b276-17186acb4746.instructions','null'),('fields.a891b39d-03a3-45e3-b276-17186acb4746.name','\"Simple One-Line Text Field\"'),('fields.a891b39d-03a3-45e3-b276-17186acb4746.searchable','false'),('fields.a891b39d-03a3-45e3-b276-17186acb4746.settings.byteLimit','null'),('fields.a891b39d-03a3-45e3-b276-17186acb4746.settings.charLimit','null'),('fields.a891b39d-03a3-45e3-b276-17186acb4746.settings.code','false'),('fields.a891b39d-03a3-45e3-b276-17186acb4746.settings.initialRows','4'),('fields.a891b39d-03a3-45e3-b276-17186acb4746.settings.multiline','false'),('fields.a891b39d-03a3-45e3-b276-17186acb4746.settings.placeholder','null'),('fields.a891b39d-03a3-45e3-b276-17186acb4746.settings.uiMode','\"normal\"'),('fields.a891b39d-03a3-45e3-b276-17186acb4746.translationKeyFormat','null'),('fields.a891b39d-03a3-45e3-b276-17186acb4746.translationMethod','\"none\"'),('fields.a891b39d-03a3-45e3-b276-17186acb4746.type','\"craft\\\\fields\\\\PlainText\"'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.columnSuffix','null'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.handle','\"jobBenefitCategories\"'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.instructions','null'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.name','\"Job Benefit Categories\"'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.searchable','false'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.settings.allowSelfRelations','false'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.settings.branchLimit','null'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.settings.localizeRelations','false'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.settings.maintainHierarchy','false'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.settings.maxRelations','null'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.settings.minRelations','null'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.settings.selectionLabel','null'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.settings.showCardsInGrid','false'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.settings.showSiteMenu','false'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.settings.source','\"group:0e530a56-1ab2-4445-9fb2-c10cb2de5d23\"'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.settings.targetSiteId','null'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.settings.validateRelatedElements','false'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.settings.viewMode','\"list\"'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.translationKeyFormat','null'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.translationMethod','\"site\"'),('fields.c8176449-1246-4efc-9b42-8e70f5b84306.type','\"craft\\\\fields\\\\Categories\"'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.columnSuffix','null'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.handle','\"jobProgrammingLanguages\"'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.instructions','null'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.name','\"Job Programming Languages\"'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.searchable','false'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.settings.allowSelfRelations','false'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.settings.branchLimit','null'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.settings.localizeRelations','false'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.settings.maintainHierarchy','false'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.settings.maxRelations','null'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.settings.minRelations','null'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.settings.selectionLabel','null'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.settings.showCardsInGrid','false'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.settings.showSiteMenu','false'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.settings.source','\"taggroup:37e6610b-1e23-42b3-8c84-853c2796c120\"'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.settings.targetSiteId','null'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.settings.validateRelatedElements','false'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.settings.viewMode','null'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.translationKeyFormat','null'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.translationMethod','\"site\"'),('fields.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b.type','\"craft\\\\fields\\\\Tags\"'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.columnSuffix','null'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.handle','\"simpleWysiwygContent\"'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.instructions','null'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.name','\"Simple WYSIWYG Content\"'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.searchable','false'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.settings.availableTransforms','\"\"'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.settings.availableVolumes','\"\"'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.settings.ckeConfig','\"ff3cbecf-0f4e-4aff-a4f8-93bd8ac46501\"'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.settings.createButtonLabel','null'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.settings.defaultTransform','null'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.settings.enableSourceEditingForNonAdmins','false'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.settings.purifierConfig','null'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.settings.purifyHtml','true'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.settings.showUnpermittedFiles','false'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.settings.showUnpermittedVolumes','false'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.settings.showWordCount','false'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.settings.wordLimit','null'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.translationKeyFormat','null'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.translationMethod','\"none\"'),('fields.fa292818-e2be-4621-a3fe-fa84e94dffd3.type','\"craft\\\\ckeditor\\\\Field\"'),('fs.uploads.hasUrls','true'),('fs.uploads.name','\"Uploads\"'),('fs.uploads.settings.path','\"@webroot/uploads\"'),('fs.uploads.type','\"craft\\\\fs\\\\Local\"'),('fs.uploads.url','\"@web/uploads\"'),('meta.__names__.0e530a56-1ab2-4445-9fb2-c10cb2de5d23','\"Job Benefit Categories\"'),('meta.__names__.37e6610b-1e23-42b3-8c84-853c2796c120','\"Job Programming Languages\"'),('meta.__names__.482b9c56-bed4-4004-9cf2-085a3eca6f49','\"Jobs\"'),('meta.__names__.65f42813-b1a9-4f17-bc3a-2d329422c5e4','\"Simple Multi-Line Text Field\"'),('meta.__names__.671d7f33-b1cc-47a2-b318-351f6abed131','\"Job\"'),('meta.__names__.7c2faeb0-e852-4965-8043-25af99e324c1','\"Green Coding Jobs\"'),('meta.__names__.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a','\"Uploads\"'),('meta.__names__.9b0e5a91-7470-4931-8137-bf361cd4b2e2','\"Image\"'),('meta.__names__.a891b39d-03a3-45e3-b276-17186acb4746','\"Simple One-Line Text Field\"'),('meta.__names__.b342a358-6ba6-41a2-b520-3bb922b51bde','\"Testsite\"'),('meta.__names__.c8176449-1246-4efc-9b42-8e70f5b84306','\"Job Benefit Categories\"'),('meta.__names__.f9d16bf2-5cd7-49fc-89d5-6f3a67c0e75b','\"Job Programming Languages\"'),('meta.__names__.fa292818-e2be-4621-a3fe-fa84e94dffd3','\"Simple WYSIWYG Content\"'),('meta.__names__.ff3cbecf-0f4e-4aff-a4f8-93bd8ac46501','\"Simple\"'),('plugins.blitz.edition','\"standard\"'),('plugins.blitz.enabled','true'),('plugins.blitz.licenseKey','\"FIQ66X673D55Z5TBP64667MM\"'),('plugins.blitz.schemaVersion','\"5.0.0.4\"'),('plugins.ckeditor.edition','\"standard\"'),('plugins.ckeditor.enabled','true'),('plugins.ckeditor.schemaVersion','\"3.0.0.0\"'),('plugins.empty-coalesce.edition','\"standard\"'),('plugins.empty-coalesce.enabled','true'),('plugins.empty-coalesce.schemaVersion','\"1.0.0\"'),('plugins.imager-x-power-pack.edition','\"standard\"'),('plugins.imager-x-power-pack.enabled','true'),('plugins.imager-x-power-pack.schemaVersion','\"1.0.0\"'),('plugins.imager-x.edition','\"lite\"'),('plugins.imager-x.enabled','true'),('plugins.imager-x.licenseKey','\"TNDE5Q46BXYMPF2K1WVY2OW6\"'),('plugins.imager-x.schemaVersion','\"4.0.0\"'),('plugins.sprig.edition','\"standard\"'),('plugins.sprig.enabled','true'),('plugins.sprig.schemaVersion','\"1.0.1\"'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.defaultPlacement','\"end\"'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.enableVersioning','true'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.entryTypes.0','\"671d7f33-b1cc-47a2-b318-351f6abed131\"'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.handle','\"jobs\"'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.maxAuthors','1'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.name','\"Jobs\"'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.propagationMethod','\"all\"'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.siteSettings.b342a358-6ba6-41a2-b520-3bb922b51bde.enabledByDefault','true'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.siteSettings.b342a358-6ba6-41a2-b520-3bb922b51bde.hasUrls','true'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.siteSettings.b342a358-6ba6-41a2-b520-3bb922b51bde.template','\"jobs/_entry\"'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.siteSettings.b342a358-6ba6-41a2-b520-3bb922b51bde.uriFormat','\"job/{slug}\"'),('sections.482b9c56-bed4-4004-9cf2-085a3eca6f49.type','\"channel\"'),('siteGroups.7c2faeb0-e852-4965-8043-25af99e324c1.name','\"Green Coding Jobs\"'),('sites.b342a358-6ba6-41a2-b520-3bb922b51bde.baseUrl','\"$DDEV_PRIMARY_URL\"'),('sites.b342a358-6ba6-41a2-b520-3bb922b51bde.enabled','true'),('sites.b342a358-6ba6-41a2-b520-3bb922b51bde.handle','\"default\"'),('sites.b342a358-6ba6-41a2-b520-3bb922b51bde.hasUrls','true'),('sites.b342a358-6ba6-41a2-b520-3bb922b51bde.language','\"en\"'),('sites.b342a358-6ba6-41a2-b520-3bb922b51bde.name','\"Testsite\"'),('sites.b342a358-6ba6-41a2-b520-3bb922b51bde.primary','true'),('sites.b342a358-6ba6-41a2-b520-3bb922b51bde.siteGroup','\"7c2faeb0-e852-4965-8043-25af99e324c1\"'),('sites.b342a358-6ba6-41a2-b520-3bb922b51bde.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Green Coding Jobs\"'),('system.schemaVersion','\"5.0.0.20\"'),('system.timeZone','\"America/Los_Angeles\"'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elementCondition','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.autocapitalize','true'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.autocomplete','false'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.autocorrect','true'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.class','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.disabled','false'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.elementCondition','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.id','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.includeInCards','false'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.inputType','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.instructions','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.label','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.max','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.min','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.name','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.orientation','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.placeholder','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.providesThumbs','false'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.readonly','false'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.requirable','false'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.size','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.step','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.tip','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.title','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\TitleField\"'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.uid','\"6d85b18f-e87f-48bb-a61a-e8f66634cb21\"'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.userCondition','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.warning','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.elements.0.width','100'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.name','\"Content\"'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.uid','\"37881f0a-f631-4347-9f74-535d972c9c68\"'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.fieldLayouts.a0b274ef-3b6f-403a-b892-7bc9e80e6f2f.tabs.0.userCondition','null'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.handle','\"jobProgrammingLanguages\"'),('tagGroups.37e6610b-1e23-42b3-8c84-853c2796c120.name','\"Job Programming Languages\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.altTranslationKeyFormat','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.altTranslationMethod','\"none\"'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elementCondition','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.autocapitalize','true'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.autocomplete','false'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.autocorrect','true'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.class','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.disabled','false'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.elementCondition','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.id','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.includeInCards','false'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.inputType','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.instructions','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.label','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.max','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.min','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.name','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.orientation','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.placeholder','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.providesThumbs','false'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.readonly','false'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.requirable','false'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.size','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.step','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.tip','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.title','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.uid','\"db8d499d-9f1b-42d2-a23c-974f2e0b91d5\"'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.userCondition','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.warning','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.0.width','100'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.attribute','\"alt\"'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.class','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.cols','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.disabled','false'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.elementCondition','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.id','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.includeInCards','false'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.instructions','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.label','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.name','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.orientation','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.placeholder','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.providesThumbs','false'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.readonly','false'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.requirable','true'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.required','false'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.rows','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.tip','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.title','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AltField\"'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.uid','\"fdef8421-7e67-4d26-b654-73cdc36d26fd\"'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.userCondition','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.warning','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.elements.1.width','100'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.name','\"Content\"'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.uid','\"a78b82fb-ce8c-4522-9ce2-03ae723cc8b3\"'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fieldLayouts.0cb16f3c-8d09-4c95-b9dd-46fe57a9e8a2.tabs.0.userCondition','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.fs','\"uploads\"'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.handle','\"uploads\"'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.name','\"Uploads\"'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.sortOrder','1'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.subpath','\"\"'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.titleTranslationKeyFormat','null'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.titleTranslationMethod','\"site\"'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.transformFs','\"\"'),('volumes.7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_lladdwctbhaiuhpyhtmffzqvhaucjwptianm` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_cuahnovvhfmqnyposlpofwvsnpqfcctylikb` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ihlwbqoiznvcwgvgslllmuxxwgehtdoimjuh` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_invrygndjmyrvzfpoqkernlbpbaquwlzkuoq` (`sourceId`),
  KEY `idx_rxzxopsqdktffafyoxycexctxwmlucmgqdhf` (`targetId`),
  KEY `idx_baakyaelvdgslmjnfeigjfcifnxuheehpnfn` (`sourceSiteId`),
  CONSTRAINT `fk_dmfkvifnzghxiedewyitsauipwkrypuliqqv` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mdojngezcmthilnyjookgxtozwohbwfibafa` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wjeshqchwwjhvwteiygksrpgwutgkqdgvlze` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
INSERT INTO `relations` VALUES (2,3,5,NULL,3,1,'2024-05-11 12:50:51','2024-05-11 17:32:31','832f9641-63db-4c66-b1b0-e31c1a9542ae'),(3,4,5,NULL,6,1,'2024-05-11 12:50:55','2024-05-11 12:50:55','eb6acb7f-0bb8-4d8d-b5d3-e72d7e8d295a'),(4,3,7,NULL,2,1,'2024-05-11 12:51:00','2024-05-11 12:51:00','080f8af9-672d-4fec-aa38-d68059752c4c'),(5,3,7,NULL,3,2,'2024-05-11 12:51:00','2024-05-11 12:51:00','50b4d204-26a1-44be-a3ca-9d8231159eaa'),(6,4,7,NULL,6,1,'2024-05-11 12:51:00','2024-05-11 12:51:00','763fe1ab-f91a-4a40-912d-4a13eb8abcd3'),(7,3,8,NULL,2,1,'2024-05-11 17:30:12','2024-05-11 17:30:12','d21d7309-b307-4505-a0aa-f39cd6a735e4'),(8,3,8,NULL,3,2,'2024-05-11 17:30:12','2024-05-11 17:30:12','c8a28bb4-e88f-4b66-9c90-9e91208e1475'),(12,6,8,NULL,12,1,'2024-05-11 17:32:18','2024-05-11 17:32:18','07fcd46f-8b0a-496d-95aa-962c58f55733'),(13,3,13,NULL,2,1,'2024-05-11 17:32:23','2024-05-11 17:32:23','f9d2888a-ed28-44b8-9aba-d13cfe23655b'),(14,3,13,NULL,3,2,'2024-05-11 17:32:23','2024-05-11 17:32:23','1031081d-3fb1-4ead-a0a5-76d2c39eacc0'),(15,6,13,NULL,12,1,'2024-05-11 17:32:23','2024-05-11 17:32:23','2f1164c9-ddc4-45ff-949c-f8589486a32d'),(17,6,5,NULL,12,1,'2024-05-11 17:32:31','2024-05-11 17:32:31','e167e659-d7e9-47ce-a9eb-df67991fe817'),(18,3,14,NULL,3,1,'2024-05-11 17:32:31','2024-05-11 17:32:31','a866082f-f323-4df5-a2cc-d0fbaab5b9bf'),(19,4,14,NULL,6,1,'2024-05-11 17:32:31','2024-05-11 17:32:31','c63c66da-c118-4319-9551-fcb23bf94bb8'),(20,6,14,NULL,12,1,'2024-05-11 17:32:31','2024-05-11 17:32:31','7b33f19c-82a4-43db-b254-7bf37ac4046f'),(25,4,8,NULL,15,1,'2024-05-11 17:32:52','2024-05-11 17:32:52','674959d2-c92a-4fb3-9732-4a3546dfff2f'),(26,3,17,NULL,2,1,'2024-05-11 17:32:52','2024-05-11 17:32:52','18610de9-1bc0-4579-b9eb-8ecf6dccf9ca'),(27,3,17,NULL,3,2,'2024-05-11 17:32:52','2024-05-11 17:32:52','4e952626-026e-400d-b5f4-4b056120a2a3'),(28,4,17,NULL,15,1,'2024-05-11 17:32:52','2024-05-11 17:32:52','9c220bec-db42-40e4-a208-e37c0af06d23'),(29,6,17,NULL,12,1,'2024-05-11 17:32:52','2024-05-11 17:32:52','86440cd6-5e48-4cee-b65c-21a304c24e4e'),(30,3,18,NULL,3,1,'2024-07-03 19:21:31','2024-07-03 19:21:31','ae3c93ad-1114-40e9-ba11-553b01fdfb06'),(31,4,18,NULL,6,1,'2024-07-03 19:21:31','2024-07-03 19:21:31','89a30368-1f85-49bd-bbb1-a6078d621a8a'),(32,6,18,NULL,12,1,'2024-07-03 19:21:31','2024-07-03 19:21:31','527e8bfe-f9e5-4e8e-845e-c7ec694668b5'),(33,3,19,NULL,3,1,'2024-07-03 19:21:31','2024-07-03 19:21:31','23abadd1-3240-45d8-aea1-f4db5dbda339'),(34,4,19,NULL,6,1,'2024-07-03 19:21:31','2024-07-03 19:21:31','be4e7c67-9f54-4d8f-afed-30099f66aba5'),(35,6,19,NULL,12,1,'2024-07-03 19:21:31','2024-07-03 19:21:31','432995a6-bbbc-4715-ba2c-857e75ef63a9'),(36,3,20,NULL,3,1,'2024-07-03 19:21:33','2024-07-03 19:21:33','9b8e49e3-2121-4e1c-987a-893a807d9038'),(37,4,20,NULL,6,1,'2024-07-03 19:21:33','2024-07-03 19:21:33','1b12b40e-ab44-4745-997f-54f302990acc'),(38,6,20,NULL,12,1,'2024-07-03 19:21:33','2024-07-03 19:21:33','8846305e-c418-4300-88da-dbc94a9a1a6a'),(39,3,21,NULL,3,1,'2024-07-03 19:21:33','2024-07-03 19:21:33','16643df1-4c2c-4b37-af09-d62d9c0d2c7b'),(40,4,21,NULL,6,1,'2024-07-03 19:21:33','2024-07-03 19:21:33','63826506-6f3b-4818-89cc-310dabf71e9a'),(41,6,21,NULL,12,1,'2024-07-03 19:21:33','2024-07-03 19:21:33','be8cbd1d-f7a2-4285-9597-40195fc27b93'),(42,3,22,NULL,3,1,'2024-07-03 19:21:36','2024-07-03 19:21:36','ec671bdb-b6fa-4c40-8a13-c6ab06c0150c'),(43,4,22,NULL,6,1,'2024-07-03 19:21:36','2024-07-03 19:21:36','65ca0ce3-5a97-44eb-a6a0-0e4f38e2e6a0'),(44,6,22,NULL,12,1,'2024-07-03 19:21:36','2024-07-03 19:21:36','01942b08-7edd-4e5c-a073-9c9f2c5bbf47'),(45,3,23,NULL,3,1,'2024-07-03 19:21:36','2024-07-03 19:21:36','8bab59e0-3f16-47a6-b2ee-ad642f7987dc'),(46,4,23,NULL,6,1,'2024-07-03 19:21:36','2024-07-03 19:21:36','dec229ee-9a1f-4c98-b928-91c83163ac2d'),(47,6,23,NULL,12,1,'2024-07-03 19:21:36','2024-07-03 19:21:36','6d4ca312-ec22-4607-ac60-dc157d770a90'),(48,3,24,NULL,2,1,'2024-07-03 19:21:40','2024-07-03 19:21:40','6a031a59-5b74-43fd-bda7-49b38b24389c'),(49,3,24,NULL,3,2,'2024-07-03 19:21:40','2024-07-03 19:21:40','a9b5a8ee-9d83-48fe-9118-559f60f473ac'),(50,4,24,NULL,15,1,'2024-07-03 19:21:40','2024-07-03 19:21:40','516d0540-ca56-4c5a-8287-1f2f07cc07e7'),(51,6,24,NULL,12,1,'2024-07-03 19:21:40','2024-07-03 19:21:40','ce1824f1-2ae2-40a0-b213-f3f8872832c1'),(52,3,25,NULL,2,1,'2024-07-03 19:21:40','2024-07-03 19:21:40','11c1907d-a045-4e47-a812-1da81252892d'),(53,3,25,NULL,3,2,'2024-07-03 19:21:40','2024-07-03 19:21:40','7ab8347e-a947-4e16-a6f6-19d3cab85537'),(54,4,25,NULL,15,1,'2024-07-03 19:21:40','2024-07-03 19:21:40','c534baaf-8b4a-45fb-88e8-68db233fbeea'),(55,6,25,NULL,12,1,'2024-07-03 19:21:40','2024-07-03 19:21:40','cac4e7eb-5412-4b8f-b033-45587185c7a8'),(56,3,26,NULL,2,1,'2024-07-03 19:21:41','2024-07-03 19:21:41','45d4db7a-b885-4254-9f9e-136f56fc778e'),(57,3,26,NULL,3,2,'2024-07-03 19:21:41','2024-07-03 19:21:41','2714320f-56f7-4c63-b164-138862e4f6e9'),(58,4,26,NULL,15,1,'2024-07-03 19:21:41','2024-07-03 19:21:41','8dc3a285-a08d-4b0f-acf9-8f2b1c623f46'),(59,6,26,NULL,12,1,'2024-07-03 19:21:41','2024-07-03 19:21:41','b912e84c-f0fe-4803-ac7d-6059004db322'),(60,3,27,NULL,2,1,'2024-07-03 19:21:41','2024-07-03 19:21:41','3a4041af-c06a-46f2-b009-bf09379fa2c2'),(61,3,27,NULL,3,2,'2024-07-03 19:21:41','2024-07-03 19:21:41','ecbd9e1a-b083-4c5d-a12f-e9d4e87c6a95'),(62,4,27,NULL,15,1,'2024-07-03 19:21:41','2024-07-03 19:21:41','86cb6a17-98ab-4bea-b616-4d1b1114358d'),(63,6,27,NULL,12,1,'2024-07-03 19:21:41','2024-07-03 19:21:41','c051f203-4d45-4f7c-8aa6-01cf3424e42e'),(64,3,28,NULL,2,1,'2024-07-03 19:21:43','2024-07-03 19:21:43','1325ce04-4724-4575-917c-c2f3980d5aea'),(65,3,28,NULL,3,2,'2024-07-03 19:21:43','2024-07-03 19:21:43','d0ecc04b-afba-4d5f-a018-146605a100fe'),(66,4,28,NULL,15,1,'2024-07-03 19:21:43','2024-07-03 19:21:43','68812c2b-b05e-4274-8d42-99d4eaff8e1e'),(67,6,28,NULL,12,1,'2024-07-03 19:21:43','2024-07-03 19:21:43','5684d50b-60f7-4159-a97f-543787ad17d9'),(68,3,29,NULL,2,1,'2024-07-03 19:21:43','2024-07-03 19:21:43','9bafc9fc-a8e6-493c-b95f-04f339b2d803'),(69,3,29,NULL,3,2,'2024-07-03 19:21:43','2024-07-03 19:21:43','d02cb10a-cd96-4f85-85f0-a1e0ee71e0fb'),(70,4,29,NULL,15,1,'2024-07-03 19:21:43','2024-07-03 19:21:43','16e15432-b38a-46ae-9991-c0f244e2e137'),(71,6,29,NULL,12,1,'2024-07-03 19:21:43','2024-07-03 19:21:43','74436a31-9b3a-4a33-9333-397cee1cbd76'),(72,3,30,NULL,2,1,'2024-07-03 19:21:44','2024-07-03 19:21:44','27c28334-78f0-4456-be8e-3553465b66d4'),(73,3,30,NULL,3,2,'2024-07-03 19:21:44','2024-07-03 19:21:44','353a347e-8016-4e68-84a8-9ddfc58f8b33'),(74,4,30,NULL,15,1,'2024-07-03 19:21:44','2024-07-03 19:21:44','b73f6eb4-4557-480d-86fd-8137c7f7f897'),(75,6,30,NULL,12,1,'2024-07-03 19:21:44','2024-07-03 19:21:44','28531a05-e207-4623-896f-72106ac4afb2'),(76,3,31,NULL,2,1,'2024-07-03 19:21:44','2024-07-03 19:21:44','86dd549c-598c-47b8-bba7-083fe1d601a7'),(77,3,31,NULL,3,2,'2024-07-03 19:21:44','2024-07-03 19:21:44','e2c6e622-c166-4ea3-82ca-b543c95fffb9'),(78,4,31,NULL,15,1,'2024-07-03 19:21:44','2024-07-03 19:21:44','c78ad5a7-b7da-49ae-95f0-38015a0458e3'),(79,6,31,NULL,12,1,'2024-07-03 19:21:44','2024-07-03 19:21:44','29b962cd-3120-40ff-b4b4-5c050b33565d'),(80,3,32,NULL,2,1,'2024-07-03 19:21:46','2024-07-03 19:21:46','78561a8a-163a-4492-adca-668e5599d865'),(81,3,32,NULL,3,2,'2024-07-03 19:21:46','2024-07-03 19:21:46','1f987876-b53c-4dea-970c-1fe788fe55c8'),(82,4,32,NULL,15,1,'2024-07-03 19:21:46','2024-07-03 19:21:46','62823201-9bc0-427f-91c1-442bd473bb06'),(83,6,32,NULL,12,1,'2024-07-03 19:21:46','2024-07-03 19:21:46','65668de1-7e09-49f2-abcf-bc3fd7cb8c11'),(84,3,33,NULL,2,1,'2024-07-03 19:21:46','2024-07-03 19:21:46','4e0e9914-39fc-4c32-89df-93332cb07b62'),(85,3,33,NULL,3,2,'2024-07-03 19:21:46','2024-07-03 19:21:46','a0b75eea-25ca-44ce-8189-0b66c0bc1c70'),(86,4,33,NULL,15,1,'2024-07-03 19:21:46','2024-07-03 19:21:46','54c38414-48e3-4ab1-a938-683149bf5593'),(87,6,33,NULL,12,1,'2024-07-03 19:21:46','2024-07-03 19:21:46','0cabe8b4-8a47-49b0-b7fc-a54394dabc87');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('13e7e571','@craft/web/assets/dashboard/dist'),('141c59f1','@craft/web/assets/iframeresizer/dist'),('1858a8b9','@craft/web/assets/vue/dist'),('1f36af9e','@craft/web/assets/updateswidget/dist'),('1f7d5046','@craft/web/assets/d3/dist'),('218cedf0','@craft/web/assets/recententries/dist'),('2204a391','@craft/web/assets/fileupload/dist'),('2a36ba27','@craft/web/assets/updates/dist'),('3378fac4','@craft/web/assets/elementresizedetector/dist'),('343d426b','@putyourlightson/sprig/resources/lib/htmx/1.9.12'),('35b4a88b','@craft/web/assets/picturefill/dist'),('3698e52c','@bower/jquery/dist'),('397978a9','@craft/web/assets/axios/dist'),('3ac65837','@craft/web/assets/timepicker/dist'),('3c68c24f','@craft/web/assets/craftsupport/dist'),('3c7f753a','@craft/web/assets/jqueryui/dist'),('3e0c158b','@craft/web/assets/xregexp/dist'),('4055bc49','@craft/web/assets/prismjs/dist'),('43ef8696','@craft/web/assets/updates/dist'),('4bdd9f20','@craft/web/assets/fileupload/dist'),('4f90d8fb','@craft/web/assets/fabric/dist'),('548760f','@craft/web/assets/cp/dist'),('55a6498b','@craft/web/assets/jqueryui/dist'),('55b1fefe','@craft/web/assets/craftsupport/dist'),('57d5293a','@craft/web/assets/xregexp/dist'),('5aa1c675','@craft/web/assets/elementresizedetector/dist'),('5c6d943a','@craft/web/assets/picturefill/dist'),('5d4af031','@putyourlightson/sprig/resources/lib/htmx/1.9.12'),('5f41d99d','@bower/jquery/dist'),('60364ee4','@craft/web/assets/jquerypayment/dist'),('60659186','@craft/web/assets/jquerytouchevents/dist'),('65a14c53','@craft/web/assets/velocity/dist'),('6722efec','@craft/web/assets/garnish/dist'),('6aa4c3ba','@craft/web/assets/feed/dist'),('6e3dc723','@craft/web/assets/datepickeri18n/dist'),('7a3ed9c0','@craft/web/assets/dashboard/dist'),('7e4fb92','@craft/web/assets/datepickeri18n/dist'),('81baedd7','@craft/web/assets/cp/dist'),('8316604a','@craft/web/assets/datepickeri18n/dist'),('8532d52b','@putyourlightson/sprig/resources/lib/htmx/1.9.12'),('878f64d3','@craft/web/assets/feed/dist'),('888aeb3a','@craft/web/assets/velocity/dist'),('8a094885','@craft/web/assets/garnish/dist'),('8ae7f5bd','@craft/web/assets/tailwindreset/dist'),('8d1de98d','@craft/web/assets/jquerypayment/dist'),('8d4e36ef','@craft/web/assets/jquerytouchevents/dist'),('8df24f9f','@craft/web/assets/selectize/dist'),('900d447','@craft/web/assets/selectize/dist'),('90eec229','@craft/web/assets/iframeresizer/dist'),('9b8fcb9e','@craft/web/assets/d3/dist'),('9bc43446','@craft/web/assets/updateswidget/dist'),('9bcad37','@craft/web/assets/jquerytouchevents/dist'),('9ef7255','@craft/web/assets/jquerypayment/dist'),('a2bb7f92','@craft/web/assets/fabric/dist'),('a57e7628','@craft/web/assets/recententries/dist'),('b1463353','@craft/web/assets/picturefill/dist'),('b291e9ac','@craft/web/assets/utilities/dist'),('b89a5997','@craft/web/assets/craftsupport/dist'),('bafe8e53','@craft/web/assets/xregexp/dist'),('bd8be371','@craft/web/assets/axios/dist'),('c5640cc6','@craft/web/assets/updater/dist'),('c7870e2','@craft/web/assets/velocity/dist'),('cb624323','@craft/web/assets/fabric/dist'),('cca74a99','@craft/web/assets/recententries/dist'),('cf2f04f8','@craft/web/assets/fileupload/dist'),('d154d253','@craft/web/assets/jqueryui/dist'),('d452dfc0','@craft/web/assets/axios/dist'),('d916e502','@putyourlightson/sprig/resources/lib/htmx/1.9.12'),('db48d51d','@craft/web/assets/utilities/dist'),('dbb34245','@bower/jquery/dist'),('de535dad','@craft/web/assets/elementresizedetector/dist'),('e156e65','@craft/web/assets/tailwindreset/dist'),('e33ec90c','@craft/web/assets/tailwindreset/dist'),('e3d07434','@craft/web/assets/garnish/dist'),('e42b732e','@craft/web/assets/selectize/dist'),('e863d166','@craft/web/assets/cp/dist'),('f21d08f7','@craft/web/assets/updateswidget/dist'),('f256f72f','@craft/web/assets/d3/dist'),('f25e37cb','@craft/web/assets/admintable/dist'),('f56c84fb','@craft/ckeditor/web/assets/ckeditor/dist'),('f937fe98','@craft/web/assets/iframeresizer/dist'),('fecc4218','@craft/web/assets/dashboard/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cqrnskdyadhhiaiqinnvxfusfpeanndihrwr` (`canonicalId`,`num`),
  KEY `fk_bxxnxcinkgjvetrtbgketrdterybligblwop` (`creatorId`),
  CONSTRAINT `fk_bkvyjbzkojxiegvpruhmisknyrjsxvmqjlmi` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_bxxnxcinkgjvetrtbgketrdterybligblwop` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,5,1,1,''),(2,8,1,1,''),(3,5,1,2,'Applied “Draft 1”'),(4,8,1,2,'Applied “Draft 1”'),(5,18,1,1,NULL),(6,20,1,1,NULL),(7,22,1,1,NULL),(8,24,1,1,NULL),(9,26,1,1,NULL),(10,28,1,1,NULL),(11,30,1,1,NULL),(12,32,1,1,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_kzdooxljbiitrfuygpggfwccxeyzhodpoesa` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' admin example com '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' admin '),(2,'slug',0,1,' 4 day work week '),(2,'title',0,1,' 4 day work week '),(3,'slug',0,1,' public transport ticket '),(3,'title',0,1,' public transport ticket '),(4,'slug',0,1,' temp sumlcyxzbftbumycdyxslhiasrejdnkapyug '),(4,'title',0,1,''),(5,'slug',0,1,' example php job '),(5,'title',0,1,' example php job '),(6,'slug',0,1,' php '),(6,'title',0,1,' php '),(8,'slug',0,1,' example svelte job '),(8,'title',0,1,' example svelte job '),(10,'slug',0,1,' fruit basket '),(10,'title',0,1,' fruit basket '),(11,'slug',0,1,' night train journeys '),(11,'title',0,1,' night train journeys '),(12,'alt',0,1,''),(12,'extension',0,1,' jpg '),(12,'filename',0,1,' rivage fa9b57hffnm unsplash jpg '),(12,'kind',0,1,' image '),(12,'slug',0,1,''),(12,'title',0,1,' rivage fa9b57hffn m unsplash '),(15,'slug',0,1,' svelte '),(15,'title',0,1,' svelte '),(18,'slug',0,1,' example php job 2 '),(18,'title',0,1,' example php job '),(20,'slug',0,1,' example php job 3 '),(20,'title',0,1,' example php job '),(22,'slug',0,1,' example php job 4 '),(22,'title',0,1,' example php job '),(24,'slug',0,1,' example svelte job 2 '),(24,'title',0,1,' example svelte job '),(26,'slug',0,1,' example svelte job 3 '),(26,'title',0,1,' example svelte job '),(28,'slug',0,1,' example svelte job 4 '),(28,'title',0,1,' example svelte job '),(30,'slug',0,1,' example svelte job 5 '),(30,'title',0,1,' example svelte job '),(32,'slug',0,1,' example svelte job 6 '),(32,'title',0,1,' example svelte job ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cujtdcdbtudcjtneyewkmdqexygzicqmggyf` (`handle`),
  KEY `idx_haodidaadpxhngxvylrnqaudlmjdislcwtfy` (`name`),
  KEY `idx_vpkyortexuzksswuatrqatlouxbmbkdbqwof` (`structureId`),
  KEY `idx_imwpcilqkmssetuzgvybbjsjstvtwczydywl` (`dateDeleted`),
  CONSTRAINT `fk_idsfhojfsmctzacruwqcinpntjmpzsdsjqqn` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Jobs','jobs','channel',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-05-11 11:57:11','2024-05-11 11:57:11',NULL,'482b9c56-bed4-4004-9cf2-085a3eca6f49');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_eumisxcjqimuzrhtbchhqhrjthqphhgwsgjc` (`typeId`),
  CONSTRAINT `fk_eumisxcjqimuzrhtbchhqhrjthqphhgwsgjc` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_haejikfxsvwyyiygrxkdlngmqoyuzsanlfht` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
INSERT INTO `sections_entrytypes` VALUES (1,1,1);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_qvshzjikkixwgzsmtxpbzhrmqljmwvlrggsr` (`sectionId`,`siteId`),
  KEY `idx_lnykgppidxqlxryspgrjoscxxmebflgdcdgu` (`siteId`),
  CONSTRAINT `fk_aelmwaiasizugwyvvvveeahiexvbfjwpsjip` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_ryfytcvoiijuhvisidbvdedctvvdwthkpiyl` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'job/{slug}','jobs/_entry',1,'2024-05-11 11:57:11','2024-05-11 11:57:11','b6064c6e-e6b8-4c35-ab5d-e9806ea2fc4f');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_cnykgagzrfjsckvuixnrqtkogyrilgjqlkcn` (`uid`),
  KEY `idx_cpvoiejrubovzcylseorgkmraydhvuzezgwb` (`token`),
  KEY `idx_icnnilhxrimfvotpvvhzqlehwqsmybdggfed` (`dateUpdated`),
  KEY `idx_xhqymaqsoxzvuzzptuurrsuinyylluotvxmk` (`userId`),
  CONSTRAINT `fk_pgullozuldzzarxkcfsgmjqssqrcihqrlezr` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'cH2dNoZiQwpdZ2d64tRXFQX6u5mC5xr5ToXqRRBVvUMFbdk23PhKRHoHFoUj7VTn_-QdoH-DMuj1mmFOM620QapkNe_1cNPRi7o-','2024-05-11 12:33:16','2024-05-11 12:51:59','8130f900-e2a9-495c-a4bb-1d75f0630f25'),(2,1,'6oDFb6i4erTRFOSsvE8nACP-M2bOKLkll8ru12f3-CHq5yVzqzp5iWkdSwo7bZXTPK0hfL-N0Cdcbv_ZhKaXB9Ze-q-6CVFWLXcn','2024-05-11 17:29:38','2024-05-11 17:40:06','661403fd-7d8e-49a8-b549-0d51729357f6'),(3,1,'gLgePbAUAW0R9KLfsyEdPf6HC2gq8r5qIDzae9dzfJ93QPffNQAYPRbNrz3cTcPrX1OzhA08e4jUmOMnC8Wf6iRd4kWh__qRbE9N','2024-05-11 17:40:06','2024-05-11 17:44:23','a766f592-6ee3-4f8b-9f3b-24d0e7835e53'),(5,1,'rF9RWgrTY-vr48oo_VXBQ8gPwePT7-hgEzCUqWsDhZLXnRwAGDVJfD0149HGAPRUXAbjqaEyifAttnEQC44ZDJdI6PF4eEQIKdPd','2024-07-03 19:21:24','2024-07-03 19:45:49','34126707-b4eb-49f7-a2c0-1a04857b07f4');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ksygnfomnqkhuhvqkiznlclzbtmzuobesovh` (`userId`,`message`),
  CONSTRAINT `fk_rubwbtdvsuclsdohbhjgrmezcyslugxtudzl` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ukksmdopfgtroezitumbqnzqoeyksokxkzpv` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Green Coding Jobs','2024-05-11 11:57:10','2024-05-11 11:57:10',NULL,'7c2faeb0-e852-4965-8043-25af99e324c1');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_iulmxfgcjsnxonfpktscsemvmslofjbvcoac` (`dateDeleted`),
  KEY `idx_fmhltugksjikmkxoihvhpliiwxtfwhtxqcsp` (`handle`),
  KEY `idx_qfjvcsfnitgpwzmmluuakaqaktfxplsopahq` (`sortOrder`),
  KEY `fk_ymrazklbxlpvdlnopkqehbafqtzmuenhrarj` (`groupId`),
  CONSTRAINT `fk_ymrazklbxlpvdlnopkqehbafqtzmuenhrarj` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'1','Testsite','default','en',1,'$DDEV_PRIMARY_URL',1,'2024-05-11 11:57:10','2024-05-11 11:57:11',NULL,'b342a358-6ba6-41a2-b520-3bb922b51bde');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sprig_playgrounds`
--

DROP TABLE IF EXISTS `sprig_playgrounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sprig_playgrounds` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `component` text,
  `variables` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sprig_playgrounds`
--

LOCK TABLES `sprig_playgrounds` WRITE;
/*!40000 ALTER TABLE `sprig_playgrounds` DISABLE KEYS */;
/*!40000 ALTER TABLE `sprig_playgrounds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_erlhxlormsgjeqyzqgtaoahacssjdetwkupu` (`structureId`,`elementId`),
  KEY `idx_chtvppgebpvepyoupetfnxixofzwatkkkygw` (`root`),
  KEY `idx_wxfboncpzpzxyeeqjxwfegkrugobxikftntz` (`lft`),
  KEY `idx_gdhzukeijxaghfeoigagdmpmxlbfzsetwybm` (`rgt`),
  KEY `idx_bmalneuneyigdrlzzjbgststikqupgobilfy` (`level`),
  KEY `idx_vqxoptdmnyavhwhxbwlkzosbwhhgxggpusln` (`elementId`),
  CONSTRAINT `fk_xbrophyangosgaqtsflvqxwodhvtyyyorgol` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
INSERT INTO `structureelements` VALUES (1,1,NULL,1,1,10,0,'2024-05-11 12:49:59','2024-05-11 17:30:44','93fab2c7-97df-43c1-b69f-910ce492af1f'),(2,1,2,1,2,3,1,'2024-05-11 12:49:59','2024-05-11 12:49:59','c05fa84d-2f5c-4072-94df-affe52d76183'),(3,1,3,1,4,5,1,'2024-05-11 12:50:21','2024-05-11 12:50:21','9791fcd7-ba8c-4c2e-aa88-45495b2e2f5d'),(4,1,10,1,6,7,1,'2024-05-11 17:30:21','2024-05-11 17:30:21','dd0f2771-b8e6-4cd0-95e6-75b4505bf540'),(5,1,11,1,8,9,1,'2024-05-11 17:30:44','2024-05-11 17:30:44','b55b0d18-bfe9-415f-bc28-1f6835a6df83');
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mhxjxgkvwrucdlqbhxxobolselfgneslkssw` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
INSERT INTO `structures` VALUES (1,1,'2024-05-11 11:57:11','2024-05-11 11:57:11',NULL,'a637430c-3835-4224-a061-6bac0abed042');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_facecefeyxkqlvkgnpnikkwklgiohprprpsr` (`key`,`language`),
  KEY `idx_lnwtogaqlplpfrmmubdajegvrxswajpexwdn` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dfqiphzkixtvwjklxmpazkadwboimijgawih` (`name`),
  KEY `idx_syiygpnzyoytexjmulflrstlmjzioqgxzldc` (`handle`),
  KEY `idx_zbqgiumjwapjerirddovinhiznnlfpzkpvbc` (`dateDeleted`),
  KEY `fk_oknvjrqtatmlmkkkcuvdemzcyopnuajjcjfy` (`fieldLayoutId`),
  CONSTRAINT `fk_oknvjrqtatmlmkkkcuvdemzcyopnuajjcjfy` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
INSERT INTO `taggroups` VALUES (1,'Job Programming Languages','jobProgrammingLanguages',3,'2024-05-11 11:57:11','2024-05-11 11:57:11',NULL,'37e6610b-1e23-42b3-8c84-853c2796c120');
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ndokcekdrqffleqknvmmlkmbbdgwhzpvdfly` (`groupId`),
  CONSTRAINT `fk_ayczgycpxcmlmtircnmqeuzpwuiqvszkubdi` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ujammjwnhzdmiilazqzplnnjdgdllbxgtexm` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
INSERT INTO `tags` VALUES (6,1,NULL,'2024-05-11 12:50:55','2024-05-11 12:50:55'),(15,1,NULL,'2024-05-11 17:32:51','2024-05-11 17:32:51');
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_raqcmsyufjylabjdxfzxerjhjtalpvvcbtwo` (`token`),
  KEY `idx_olvkffsfumngicaxloqqvkbmsvkmyzeziokd` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eezoovxhkrapvzawatkdrqacahktznxnrokz` (`handle`),
  KEY `idx_gedliscpkkhtwblkbmivcmcuwqmzcafjaoxa` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rybqnrxxliudebjwjurvolbruqyblurqotdr` (`groupId`,`userId`),
  KEY `idx_lwqhdaabsuqansagrrcenlkrgxbreslshfyk` (`userId`),
  CONSTRAINT `fk_qebryjzvvehxlisnoivarhpqhviasqfytpbu` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sdowpxljrpaujwxisqadtxgoobmhurmkldsf` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_mmnqbagirhhiftrkbxucdkjzbubxantgsbvg` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_bfvfbcvgdqqzsojcpshuoflwvgbqpulnoqhd` (`permissionId`,`groupId`),
  KEY `idx_ozgsbzqrgatpvflyvhhnpremkkapdzzzaboy` (`groupId`),
  CONSTRAINT `fk_gwlfxpkmflfjmeohhkebirhpmiqimdjamozp` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yuefjiuvgnwcndkegkmgrdhcuaykorurtsgd` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gxfwdulpzoybwioywkbgzswtcwcpisrdaaby` (`permissionId`,`userId`),
  KEY `idx_zajcwormlpdaoxjuxqeilljtwengbbedbuhr` (`userId`),
  CONSTRAINT `fk_ciwdbguwjtqxsfbuqnsmlwzeybqgugzfjnuc` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_giktispbotybpxpqlcqhlxjuznqmcgprucit` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_chgaslnzxourshmiutyfiqgekprchwfseshz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\": \"en\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_uzcqgmvcqsorkocxqvdisibgbsbhbjodiujd` (`active`),
  KEY `idx_yfovvyxgznijdkpigjiqtbylusanaotbcvjl` (`locked`),
  KEY `idx_uykqddzgobvneewecekjydhhkqrorxxhxpku` (`pending`),
  KEY `idx_kkfacgmsvdzdzcgymgcdmwtwpcvdkxbnawob` (`suspended`),
  KEY `idx_bunymtyrkkxflaxkeeuxjlvuqilgwskpvpan` (`verificationCode`),
  KEY `idx_bvstfkfozncqqlgoaadromdmqlolzcrjwcis` (`email`),
  KEY `idx_vdmeewqtfagypjflczsfelwghzcrjzpagwep` (`username`),
  KEY `fk_qitigsnrdckoqjwvqliwwzaxliecnxlphlnc` (`photoId`),
  CONSTRAINT `fk_kthfheklnuppyqijmskjqxjlnwefijskcuqd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qitigsnrdckoqjwvqliwwzaxliecnxlphlnc` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'admin@example.com','$2y$13$rgVxVWzE7n8Ndx1NAxoLGeDXOKOES1J2aiwHyMMckWSRxoiW4TV4S','2024-07-03 19:21:24',NULL,NULL,NULL,'2024-07-03 19:21:21',NULL,1,NULL,NULL,NULL,0,'2024-05-11 11:57:11','2024-05-11 11:57:11','2024-07-03 19:21:24');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_zudblspauknvnjxlxnpwvqxijdliubygteek` (`name`,`parentId`,`volumeId`),
  KEY `idx_bkgtqxpepyblaptjqzrueyconhrvhjlmwwjy` (`parentId`),
  KEY `idx_hoohjdiimssijlayaogtszhbznznillownmk` (`volumeId`),
  CONSTRAINT `fk_fytokdpcemkxqbiizndqkztackprrxxixceq` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ovozsjddeekxeynbwsvzshqbpcsggqwasbtn` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Uploads','','2024-05-11 12:51:54','2024-05-11 12:51:54','f8b0298a-fb57-4baf-b317-bf1bf0169e98'),(2,NULL,NULL,'Temporary Uploads',NULL,'2024-05-11 17:29:42','2024-05-11 17:29:42','38c5ef6b-f144-409f-b0a3-63f35138141a'),(3,2,NULL,'user_1','user_1/','2024-05-11 17:29:42','2024-05-11 17:29:42','013870ee-5c72-47f1-95db-8ad40620e39d');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yfokmtrckkaayakhvvhlzlnylxfvmucurxta` (`name`),
  KEY `idx_rkbdvgtepvhmcpcftjydedtpfcltqmhpobzz` (`handle`),
  KEY `idx_ppwdalaufwsgzelicdwzxeflcvqbiyrobjya` (`fieldLayoutId`),
  KEY `idx_fjgamwkzyszubtzkozdtoegqpkczvbbylldf` (`dateDeleted`),
  CONSTRAINT `fk_ymqfdcgalnvacabofabedhwwczrcgtunyrqk` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,4,'Uploads','uploads','uploads','','','','site',NULL,'none',NULL,1,'2024-05-11 12:51:54','2024-05-11 12:51:54',NULL,'7fc2cb89-cf90-4bbd-aa1f-80bad9629b3a');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_yhsfyuzleimujwmgivqqouzvsuiclkopnqks` (`userId`),
  CONSTRAINT `fk_yhsfyuzleimujwmgivqqouzvsuiclkopnqks` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pjhxslbjnjfnfclpvdageazbqhddijxmimfx` (`userId`),
  CONSTRAINT `fk_gxmeztswxoiwhzydidodwgfhogvhlgcfomsq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2024-05-11 12:33:16','2024-05-11 12:33:16','532b856e-7146-4f33-851f-6fcf82d67aa5'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-05-11 12:33:16','2024-05-11 12:33:16','02384afd-6c3e-48a7-be54-a8af7ee3f252'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-05-11 12:33:16','2024-05-11 12:33:16','17ddb293-51b7-47a3-b3b6-39b54239b93b'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2024-05-11 12:33:16','2024-05-11 12:33:16','b4eee5ca-cab3-465d-9ca8-21f9dbb21979');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-03 19:46:01
